/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/common/config/element-actions-config.js":
/*!*****************************************************!*\
  !*** ./src/common/config/element-actions-config.js ***!
  \*****************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _element_type_config_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./element-type-config.js */ "./src/common/config/element-type-config.js");


const { VALID_ELEMENT_TYPE } = _element_type_config_js__WEBPACK_IMPORTED_MODULE_0__["default"];

/**
 * Valid Actions list
 */
const VALID_ACTIONS = {
  check: 'check',
  clearText: 'clearText',
  click: 'click',
  doubleClick: 'doubleClick',
  getAttribute: 'getAttribute',
  getLinkText: 'getLinkText',
  getSelectedText: 'getSelectedText',
  getSelectedValue: 'getSelectedValue',
  getText: 'getText',
  getValue: 'getValue',
  isChecked: 'isChecked',
  isRadioButtonSelected: 'isRadioButtonSelected',
  selectByIndex: 'selectByIndex',
  selectByText: 'selectByText',
  selectByValue: 'selectByValue',
  selectComboBox: 'selectComboBox',
  selectRadioButton: 'selectRadioButton',
  setText: 'setText',
  switchToDefaultContent: 'switchToDefaultContent',
  switchToIframeByElement: 'switchToIframeByElement',
  switchToIframeByIndex: 'switchToIframeByIndex',
  switchToParentFrame: 'switchToParentFrame',
  unCheck: 'unCheck',
};

/**
 * Valid Actions list for element type
 */
const ELEMENT_TYPE_ACTIONS_MAPPING = {
  [VALID_ELEMENT_TYPE.button]: [
    VALID_ACTIONS.click,
    VALID_ACTIONS.doubleClick,
    VALID_ACTIONS.getAttribute,
    VALID_ACTIONS.getText,
  ],
  [VALID_ELEMENT_TYPE.checkbox]: [
    VALID_ACTIONS.check,
    VALID_ACTIONS.isChecked,
    VALID_ACTIONS.unCheck,
    VALID_ACTIONS.getAttribute,
  ],
  [VALID_ELEMENT_TYPE.combobox]: [
    VALID_ACTIONS.getValue,
    VALID_ACTIONS.selectComboBox,
  ],
  [VALID_ELEMENT_TYPE.dropdown]: [
    VALID_ACTIONS.selectByIndex,
    VALID_ACTIONS.selectByText,
    VALID_ACTIONS.selectByValue,
    VALID_ACTIONS.getSelectedText,
    VALID_ACTIONS.getSelectedValue,
  ],
  [VALID_ELEMENT_TYPE.iframe]: [
    VALID_ACTIONS.switchToIframeByIndex,
    VALID_ACTIONS.switchToIframeByElement,
    VALID_ACTIONS.switchToParentFrame,
    VALID_ACTIONS.switchToDefaultContent,
  ],
  [VALID_ELEMENT_TYPE.image]: [
    VALID_ACTIONS.doubleClick,
    VALID_ACTIONS.getAttribute,
    VALID_ACTIONS.click,
  ],
  [VALID_ELEMENT_TYPE.label]: [
    VALID_ACTIONS.getText,
  ],
  [VALID_ELEMENT_TYPE.link]: [
    VALID_ACTIONS.click,
    VALID_ACTIONS.getLinkText,
  ],
  [VALID_ELEMENT_TYPE.radio]: [
    VALID_ACTIONS.selectRadioButton,
    VALID_ACTIONS.isRadioButtonSelected,
    VALID_ACTIONS.getAttribute,
  ],
  [VALID_ELEMENT_TYPE.textarea]: [
    VALID_ACTIONS.getValue,
    VALID_ACTIONS.clearText,
    VALID_ACTIONS.setText,
  ],
  [VALID_ELEMENT_TYPE.textbox]: [
    VALID_ACTIONS.getValue,
    VALID_ACTIONS.clearText,
    VALID_ACTIONS.getAttribute,
    VALID_ACTIONS.setText,
  ],
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  ELEMENT_TYPE_ACTIONS_MAPPING,
});


/***/ }),

/***/ "./src/common/config/element-type-config.js":
/*!**************************************************!*\
  !*** ./src/common/config/element-type-config.js ***!
  \**************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _html_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./html.js */ "./src/common/config/html.js");


/**
 * Valid Element Type from Collab framework
 */
const VALID_ELEMENT_TYPE = {
  button: 'Button',
  checkbox: 'CheckBox',
  combobox: 'ComboBox',
  dropdown: 'DropDown',
  image: 'Image',
  iframe: 'iframe',
  link: 'Link',
  label: 'Label',
  textarea: 'TextArea',
  textbox: 'TextBox',
  radio: 'RadioButton',
};

/**
 * Map Element Type based on html tag
 */
const ELEMENT_TAGNAME_MAPPING = {
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.button]: VALID_ELEMENT_TYPE.button,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.h1]: VALID_ELEMENT_TYPE.label,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.h2]: VALID_ELEMENT_TYPE.label,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.h3]: VALID_ELEMENT_TYPE.label,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.h4]: VALID_ELEMENT_TYPE.label,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.h5]: VALID_ELEMENT_TYPE.label,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.iframe]: VALID_ELEMENT_TYPE.iframe,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.img]: VALID_ELEMENT_TYPE.image,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.label]: VALID_ELEMENT_TYPE.label,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.link]: VALID_ELEMENT_TYPE.link,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.p]: VALID_ELEMENT_TYPE.label,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.path]: VALID_ELEMENT_TYPE.image,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.select]: VALID_ELEMENT_TYPE.dropdown,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.svg]: VALID_ELEMENT_TYPE.image,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.textarea]: VALID_ELEMENT_TYPE.textarea,
};

/**
 * Map Element Type based on input tag type
 */
const ELEMENT_INPUT_TYPE_MAPPING = {
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.button]: VALID_ELEMENT_TYPE.button,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.checkbox]: VALID_ELEMENT_TYPE.checkbox,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.color]: VALID_ELEMENT_TYPE.textbox,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.date]: VALID_ELEMENT_TYPE.textbox,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.dateTimeLocal]: VALID_ELEMENT_TYPE.textbox,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.email]: VALID_ELEMENT_TYPE.textbox,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.file]: VALID_ELEMENT_TYPE.button,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.image]: VALID_ELEMENT_TYPE.image,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.month]: VALID_ELEMENT_TYPE.textbox,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.number]: VALID_ELEMENT_TYPE.textbox,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.password]: VALID_ELEMENT_TYPE.textbox,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.radio]: VALID_ELEMENT_TYPE.radio,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.range]: VALID_ELEMENT_TYPE.textbox,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.reset]: VALID_ELEMENT_TYPE.button,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.search]: VALID_ELEMENT_TYPE.textbox,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.submit]: VALID_ELEMENT_TYPE.button,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.tel]: VALID_ELEMENT_TYPE.textbox,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.text]: VALID_ELEMENT_TYPE.textbox,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.time]: VALID_ELEMENT_TYPE.textbox,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.url]: VALID_ELEMENT_TYPE.textbox,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.week]: VALID_ELEMENT_TYPE.textbox,
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  VALID_ELEMENT_TYPE,
  ELEMENT_TAGNAME_MAPPING,
  ELEMENT_INPUT_TYPE_MAPPING,
});


/***/ }),

/***/ "./src/common/config/element-verification-config.js":
/*!**********************************************************!*\
  !*** ./src/common/config/element-verification-config.js ***!
  \**********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _element_type_config_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./element-type-config.js */ "./src/common/config/element-type-config.js");


const { VALID_ELEMENT_TYPE } = _element_type_config_js__WEBPACK_IMPORTED_MODULE_0__["default"];

/**
 * Valid Verification type for collab framework
 */
const VALID_VERIFICATION = {
  verifyDropDownValues: 'verifyDropDownValues',
  verifyElementAttribute: 'verifyElementAttribute',
  verifyElementState: 'verifyElementState',
  verifyElementText: 'verifyElementText',
  verifyElementValue: 'verifyElementValue',
  verifyIsElementDisplayed: 'verifyIsElementDisplayed',
  verifyIsElementPresent: 'verifyIsElementPresent',
};

/**
 * Valid verification list for element type
 */
const ELEMENT_TYPE_VERIFICATION_MAPPING = {
  [VALID_ELEMENT_TYPE.button]: [
    VALID_VERIFICATION.verifyElementAttribute,
    VALID_VERIFICATION.verifyElementState,
    VALID_VERIFICATION.verifyElementText,
    VALID_VERIFICATION.verifyElementValue,
    VALID_VERIFICATION.verifyIsElementDisplayed,
    VALID_VERIFICATION.verifyIsElementPresent,
  ],
  [VALID_ELEMENT_TYPE.checkbox]: [
    VALID_VERIFICATION.verifyElementAttribute,
    VALID_VERIFICATION.verifyElementState,
    VALID_VERIFICATION.verifyElementText,
    VALID_VERIFICATION.verifyElementValue,
    VALID_VERIFICATION.verifyIsElementDisplayed,
    VALID_VERIFICATION.verifyIsElementPresent,
  ],
  [VALID_ELEMENT_TYPE.combobox]: [
    VALID_VERIFICATION.verifyElementAttribute,
    VALID_VERIFICATION.verifyElementState,
    VALID_VERIFICATION.verifyElementText,
    VALID_VERIFICATION.verifyElementValue,
    VALID_VERIFICATION.verifyIsElementDisplayed,
    VALID_VERIFICATION.verifyIsElementPresent,
  ],
  [VALID_ELEMENT_TYPE.dropdown]: [
    VALID_VERIFICATION.verifyDropDownValues,
    VALID_VERIFICATION.verifyElementAttribute,
    VALID_VERIFICATION.verifyElementState,
    VALID_VERIFICATION.verifyElementText,
    VALID_VERIFICATION.verifyElementValue,
    VALID_VERIFICATION.verifyIsElementDisplayed,
    VALID_VERIFICATION.verifyIsElementPresent,
  ],
  [VALID_ELEMENT_TYPE.iframe]: [
    VALID_VERIFICATION.verifyElementAttribute,
    VALID_VERIFICATION.verifyElementState,
    VALID_VERIFICATION.verifyElementText,
    VALID_VERIFICATION.verifyElementValue,
    VALID_VERIFICATION.verifyIsElementDisplayed,
    VALID_VERIFICATION.verifyIsElementPresent,
  ],
  [VALID_ELEMENT_TYPE.image]: [
    VALID_VERIFICATION.verifyElementAttribute,
    VALID_VERIFICATION.verifyElementState,
    VALID_VERIFICATION.verifyElementText,
    VALID_VERIFICATION.verifyElementValue,
    VALID_VERIFICATION.verifyIsElementDisplayed,
    VALID_VERIFICATION.verifyIsElementPresent,
  ],
  [VALID_ELEMENT_TYPE.label]: [
    VALID_VERIFICATION.verifyElementAttribute,
    VALID_VERIFICATION.verifyElementState,
    VALID_VERIFICATION.verifyElementText,
    VALID_VERIFICATION.verifyElementValue,
    VALID_VERIFICATION.verifyIsElementDisplayed,
    VALID_VERIFICATION.verifyIsElementPresent,
  ],
  [VALID_ELEMENT_TYPE.link]: [
    VALID_VERIFICATION.verifyElementAttribute,
    VALID_VERIFICATION.verifyElementState,
    VALID_VERIFICATION.verifyElementText,
    VALID_VERIFICATION.verifyElementValue,
    VALID_VERIFICATION.verifyIsElementDisplayed,
    VALID_VERIFICATION.verifyIsElementPresent,
  ],
  [VALID_ELEMENT_TYPE.radio]: [
    VALID_VERIFICATION.verifyElementAttribute,
    VALID_VERIFICATION.verifyElementState,
    VALID_VERIFICATION.verifyElementText,
    VALID_VERIFICATION.verifyElementValue,
    VALID_VERIFICATION.verifyIsElementDisplayed,
    VALID_VERIFICATION.verifyIsElementPresent,
  ],
  [VALID_ELEMENT_TYPE.textarea]: [
    VALID_VERIFICATION.verifyElementAttribute,
    VALID_VERIFICATION.verifyElementState,
    VALID_VERIFICATION.verifyElementText,
    VALID_VERIFICATION.verifyElementValue,
    VALID_VERIFICATION.verifyIsElementDisplayed,
    VALID_VERIFICATION.verifyIsElementPresent,
  ],
  [VALID_ELEMENT_TYPE.textbox]: [
    VALID_VERIFICATION.verifyElementAttribute,
    VALID_VERIFICATION.verifyElementState,
    VALID_VERIFICATION.verifyElementText,
    VALID_VERIFICATION.verifyElementValue,
    VALID_VERIFICATION.verifyIsElementDisplayed,
    VALID_VERIFICATION.verifyIsElementPresent,
  ],
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  ELEMENT_TYPE_VERIFICATION_MAPPING,
});


/***/ }),

/***/ "./src/common/config/html.js":
/*!***********************************!*\
  !*** ./src/common/config/html.js ***!
  \***********************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const TAGS = {
  a: 'A',
  button: 'BUTTON',
  div: 'DIV',
  h1: 'H1',
  h2: 'H2',
  h3: 'H3',
  h4: 'H4',
  h5: 'H5',
  i: 'I',
  input: 'INPUT',
  iframe: 'IFRAME',
  img: 'IMG',
  label: 'LABEL',
  li: 'LI',
  link: 'LINK',
  option: 'OPTION',
  p: 'P',
  path: 'PATH',
  select: 'SELECT',
  span: 'SPAN',
  svg: 'SVG',
  strong: 'STRONG',
  textarea: 'TEXTAREA',
};

const ATTRIBUTES = {
  alt: 'alt',
  ariaLabel: 'aria-label',
  class: 'class',
  dataTestId: 'data-testid',
  href: 'href',
  id: 'id',
  name: 'name',
  role: 'role',
  src: 'src',
  title: 'title',
  type: 'type',
};

/**
 * Input tag types
 */
const INPUT_TYPE = {
  button: 'button',
  checkbox: 'checkbox',
  color: 'color',
  date: 'date',
  dateTimeLocal: 'datetime-local',
  email: 'email',
  file: 'file',
  hidden: 'hidden',
  image: 'image',
  month: 'month',
  number: 'number',
  password: 'password',
  radio: 'radio',
  range: 'range',
  reset: 'reset',
  search: 'search',
  submit: 'submit',
  tel: 'tel',
  text: 'text',
  time: 'time',
  url: 'url',
  week: 'week',
};

const CONTAINER_TAGS = [
  TAGS.span,
  TAGS.div,
  TAGS.p,
  TAGS.i,
  TAGS.li,
  TAGS.strong,
];

const HEADER_TAGS = [
  TAGS.h1,
  TAGS.h2,
  TAGS.h3,
  TAGS.h4,
  TAGS.h5,
];

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  ATTRIBUTES,
  CONTAINER_TAGS,
  HEADER_TAGS,
  INPUT_TYPE,
  TAGS,
});


/***/ }),

/***/ "./src/common/config/locators-config.js":
/*!**********************************************!*\
  !*** ./src/common/config/locators-config.js ***!
  \**********************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const LOCATOR_TYPE = {
  id: 'id',
  name: 'name',
  xpath: 'xpath',
  css: 'css',
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  LOCATOR_TYPE,
});


/***/ }),

/***/ "./src/common/config/pomMaster.js":
/*!****************************************!*\
  !*** ./src/common/config/pomMaster.js ***!
  \****************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "pomMasterJSON": () => (/* binding */ pomMasterJSON),
/* harmony export */   "locatorsMasterJson": () => (/* binding */ locatorsMasterJson)
/* harmony export */ });
/* eslint-disable */
// POM JSON SAMPLE schema
const pomMasterJSON = [
  {
    "pageName": "",
    "operation": "",
    "parentClassName": "",
    "childClassNames": "",
    "locators": [
    ]
  }
]

// POM JSON LOCATOR SAMPLE schema
const locatorsMasterJson = {
  "elementName": "",
  "elementType": "",
  "locatorIdentifierType": "",
  "locatorIdentifierValue": "",
  "elementActionMethods": "",
  "elementVerificationMethods": ""
}

/* eslint-enable */


/***/ }),

/***/ "./src/common/config/web-config.js":
/*!*****************************************!*\
  !*** ./src/common/config/web-config.js ***!
  \*****************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/**
 * Request Message names between plugin and web page content script
 */
const MESSAGE_TYPE = {
  elementRightClicked: 'elementRightClicked',
  spyElement: 'spyElement',
  extensionIsOpen: 'extensionIsOpen',
};

/**
 * DOM element event types
 */
const EVENT_TYPE = {
  contextMenu: 'contextmenu',
  change: 'change',
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  EVENT_TYPE,
  MESSAGE_TYPE,
});


/***/ }),

/***/ "./src/common/lib/dom-element/element-data.js":
/*!****************************************************!*\
  !*** ./src/common/lib/dom-element/element-data.js ***!
  \****************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _config_html_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../config/html.js */ "./src/common/config/html.js");


function getElementAttributeAriaLabel(element) {
  return element.getAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.ariaLabel);
}

function getElementAttributeAlt(element) {
  return element.getAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.alt);
}

function getElementAttributeClassName(element) {
  let className = element.getAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES["class"]);
  if (className) {
    className = className.trim()
      .replace('\n', ' ')
      .split(' ')
      .filter((i) => i.length > 0)
      .join(' ');
  }
  return className;
}

function getElementAttributeDataTestId(element) {
  return element.getAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.dataTestId);
}

function getElementAttributeHref(element) {
  return element.getAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.href);
}

function getElementAttributeId(element) {
  return element.getAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.id);
}

function getElementAttributeName(element) {
  return element.getAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.name);
}

function getElementAttributeRole(element) {
  return element.getAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.role);
}

function getElementAttributeSrc(element) {
  return element.getAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.src);
}

function getElementAttributeTitle(element) {
  return element.getAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.title);
}

function getElementAttributeType(element) {
  if (typeof element.getAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.type) === 'string') {
    return element.getAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.type).toLowerCase();
  }
  return element.getAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.type);
}

/**
 * get children node list
 * @param {*} parentElement
 * @returns array of node list
 */
function getElementChildren(parentElement) {
  let children = [];
  if (parentElement.children) {
    children = Array.from(parentElement.children);
  }
  return children;
}

function getElementInnerText(element) {
  let innerText = null;

  if (element.text) {
    innerText = element.text.trim().slice(0, 150);
  } else if (element.textContent) {
    innerText = element.textContent.trim().slice(0, 150);
  } else if (element.innerText) {
    innerText = element.innerText.trim().slice(0, 150);
  }

  return innerText;
}

function getElementInnerValue(element) {
  return element.value;
}

function getElementOffsetParent(element) {
  if (getElementAttributeId(element) !== 'content') {
    return element.offsetParent;
  }
  return null;
}

function getElementParent(element) {
  return element.parentElement;
}

function getElementPreviousSibling(element) {
  return element.previousElementSibling;
}

function getElementSiblingLabelName(element) {
  const previousSibling = getElementPreviousSibling(element);

  if (previousSibling && previousSibling.tagName === _config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.label) {
    return element.previousElementSibling.innerText;
  }
  return false;
}

function getElementTagName(element) {
  if (typeof element.tagName === 'string') {
    return element.tagName.toUpperCase();
  }
  return element.tagName;
}

function isHavingAttribute(element, attribute) {
  return element.hasAttribute(attribute);
}

function isHavingDataTestIdAttribute(element) {
  return element.hasAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.dataTestId);
}

function isHavingIdAttribute(element) {
  return element.hasAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.id);
}

function isHavingNameAttribute(element) {
  return element.hasAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.name);
}

function isHavingTitleAttribute(element) {
  return element.hasAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.title);
}

function isButtonTag(element) {
  return getElementTagName(element) === _config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.button;
}

function isInputHtmlTag(element) {
  return getElementTagName(element) === _config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.input;
}

function isImageTag(element) {
  return getElementTagName(element) === _config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.img;
}

function isHyperLinkTag(element) {
  return getElementTagName(element) === _config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.a;
}

function isLabelTag(element) {
  return getElementTagName(element) === _config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.label;
}

function isRadioInputTag(element) {
  if (isInputHtmlTag(element)) {
    return getElementAttributeType(element) === _config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.radio;
  }
  return false;
}

function isCheckboxInputTag(element) {
  if (isInputHtmlTag(element)) {
    return getElementAttributeType(element) === _config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.checkbox;
  }
  return false;
}

function isMultiLocatorName(locatorByName) {
  return document.getElementsByName(locatorByName).length > 1;
}

function getElementsByXpath(xpath) {
  try {
    const result = [];
    const nodeList = document.evaluate(xpath, document, null, XPathResult.ANY_TYPE, null);
    let node = nodeList.iterateNext();
    while (node) {
      result.push(node);
      node = nodeList.iterateNext();
    }
    return result;
  } catch {
    return null;
  }
}

function getElementsBySelector(selector) {
  try {
    return document.querySelectorAll(selector);
  } catch {
    return null;
  }
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  getElementAttributeAlt,
  getElementAttributeAriaLabel,
  getElementAttributeClassName,
  getElementAttributeDataTestId,
  getElementAttributeHref,
  getElementAttributeId,
  getElementAttributeName,
  getElementAttributeRole,
  getElementAttributeSrc,
  getElementAttributeTitle,
  getElementAttributeType,
  getElementChildren,
  getElementInnerText,
  getElementInnerValue,
  getElementOffsetParent,
  getElementParent,
  getElementPreviousSibling,
  getElementSiblingLabelName,
  getElementsBySelector,
  getElementsByXpath,
  getElementTagName,
  isButtonTag,
  isCheckboxInputTag,
  isHavingAttribute,
  isHavingDataTestIdAttribute,
  isHavingIdAttribute,
  isHavingNameAttribute,
  isHavingTitleAttribute,
  isHyperLinkTag,
  isInputHtmlTag,
  isImageTag,
  isLabelTag,
  isMultiLocatorName,
  isRadioInputTag,
});


/***/ }),

/***/ "./src/common/lib/dom-element/element-notify.js":
/*!******************************************************!*\
  !*** ./src/common/lib/dom-element/element-notify.js ***!
  \******************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _config_locators_config_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../config/locators-config.js */ "./src/common/config/locators-config.js");
/* harmony import */ var _element_data_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./element-data.js */ "./src/common/lib/dom-element/element-data.js");



const { LOCATOR_TYPE } = _config_locators_config_js__WEBPACK_IMPORTED_MODULE_0__["default"];

const FLASH_ELEMENT_IN_SECONDS = 2;

const NOTIFY_RESPONSE = {
  singleElement: 'singleElement',
  invalid: 'invalid',
  multiElement: 'multiElement',
};

function getElementList(locatorType, locatorValue) {
  let elementList = [];
  switch (locatorType) {
  case LOCATOR_TYPE.css:
    elementList = _element_data_js__WEBPACK_IMPORTED_MODULE_1__["default"].getElementsBySelector(locatorValue);
    break;
  case LOCATOR_TYPE.id:
    if (document.getElementById(locatorValue)) {
      elementList.push(document.getElementById(locatorValue));
    }
    break;
  case LOCATOR_TYPE.name:
    elementList = document.getElementsByName(locatorValue);
    break;
  default:
    elementList = _element_data_js__WEBPACK_IMPORTED_MODULE_1__["default"].getElementsByXpath(locatorValue);
    break;
  }
  return elementList;
}

function wait(seconds) {
  return new Promise((resolve) => setTimeout(resolve, seconds * 1000));
}

function flashElement(element, timeOut) {
  // extract style
  const { borderColor, borderStyle, borderWidth } = element.style;
  element.style.borderColor = 'red';
  element.style.borderStyle = 'dashed';
  element.style.borderWidth = 'medium';
  wait(timeOut).then(() => {
    // reset the style
    element.style.borderColor = borderColor || '';
    element.style.borderStyle = borderStyle || '';
    element.style.borderWidth = borderWidth || '';
  });
}

function notifyElement(element) {
  element.focus();
  flashElement(element, FLASH_ELEMENT_IN_SECONDS);
}

function notify(locatorType, locatorValue) {
  try {
    let result;
    const elementList = getElementList(locatorType, locatorValue);
    if (elementList && elementList.length === 1) {
      notifyElement(elementList[0]);
      result = NOTIFY_RESPONSE.singleElement;
    } else if (elementList.length > 1) {
      result = NOTIFY_RESPONSE.multiElement;
    } else {
      result = NOTIFY_RESPONSE.invalid;
    }
    return result;
  } catch (e) {
    console.error(e);
    return NOTIFY_RESPONSE.invalid;
  }
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  notify,
  NOTIFY_RESPONSE,
});


/***/ }),

/***/ "./src/common/lib/dom-element/elements.js":
/*!************************************************!*\
  !*** ./src/common/lib/dom-element/elements.js ***!
  \************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _config_html_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../config/html.js */ "./src/common/config/html.js");


const ERROR_CLASS_NAME = 'error';
const WARNING_CLASS_NAME = 'warning';
const ERROR_MESSAGE_NO_INPUT = 'This is required field';
const WARNING_MULTI_LOCATOR_MESSAGE = 'Multi elements Locator';
const ERROR_INVALID_LOCATOR = 'Invalid or Locator not found';

function errorSpan() {
  const spanElement = document.createElement(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.span);
  spanElement.classList.add(ERROR_CLASS_NAME);
  return spanElement;
}

function warningSpan() {
  const spanElement = document.createElement(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.span);
  spanElement.classList.add(WARNING_CLASS_NAME);
  return spanElement;
}

function isHavingErrorClass(element) {
  if(element.getAttribute) {
    return element.getAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES["class"]) === ERROR_CLASS_NAME;
  }
  return null;
}

function removeInputError(element) {
  const previousElement = element.nextSibling;
  if (previousElement && isHavingErrorClass(previousElement)) {
    previousElement.remove();
  }
}

function showNoInputError(element, message = null) {
  const errorMessage = message || ERROR_MESSAGE_NO_INPUT;
  removeInputError(element);
  const errorElement = errorSpan();
  element.parentNode.insertBefore(errorElement, element.nextSibling);
  errorElement.innerHTML = errorMessage;
}

function showInputError(element, message) {
  removeInputError(element);
  const errorElement = errorSpan();
  element.parentNode.insertBefore(errorElement, element.nextSibling);
  errorElement.innerHTML = message;
}

function showInvalidLocatorError(element) {
  showInputError(element, ERROR_INVALID_LOCATOR);
}

function isHavingWarning(element) {
  return element.getAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES["class"]) === WARNING_CLASS_NAME;
}

function isEmptyField(element) {
  return element.value === '';
}

function resetMultiLocatorWarning(element) {
  const previousElement = element.previousElementSibling;
  if (previousElement && isHavingWarning(previousElement)) {
    previousElement.remove();
  }
}

function showMultiLocatorWarning(element) {
  resetMultiLocatorWarning(element);
  const spanElement = warningSpan();
  element.parentNode.insertBefore(spanElement, element);
  spanElement.innerHTML = WARNING_MULTI_LOCATOR_MESSAGE;
}

function addListBoxOption(listBoxElement, innerText) {
  const listOption = document.createElement(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.li);
  listOption.setAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.id, innerText);
  listOption.setAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.role, 'option');
  listOption.setAttribute('aria-selected', 'false');
  listOption.innerText = innerText;
  listBoxElement.appendChild(listOption);
}

function resetListBoxOptions(element) {
  if (element) {
    element.innerHTML = '';
  }
}

function resetElementValue(element) {
  if (element) {
    element.value = '';
  }
}

function loadListBoxOptions(element, optionsList) {
  if (element && optionsList.length > 0) {
    resetListBoxOptions(element);
    Array.from(new Set(optionsList)).forEach((value) => {
      addListBoxOption(element, value);
    });
  } else {
    resetListBoxOptions(element);
  }
}

function getSelectedRadioButton(groupName) {
  const radiolist = document.getElementsByName(groupName);
  if (radiolist) {
    // eslint-disable-next-line no-restricted-syntax
    for (const radioElement of radiolist) {
      if (radioElement.checked) {
        return radioElement.value;
      }
    }
  }
  return null;
}

function getListBoxItems(listElement) {
  const result = [];
  const itemList = listElement.querySelectorAll(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.li);
  itemList.forEach((item) => {
    result.push(item.textContent);
  });
  return result;
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  errorSpan,
  getListBoxItems,
  getSelectedRadioButton,
  isEmptyField,
  loadListBoxOptions,
  showNoInputError,
  showMultiLocatorWarning,
  showInputError,
  showInvalidLocatorError,
  removeInputError,
  resetElementValue,
  resetMultiLocatorWarning,
  resetListBoxOptions,
});


/***/ }),

/***/ "./src/common/lib/listbox/listbox.js":
/*!*******************************************!*\
  !*** ./src/common/lib/listbox/listbox.js ***!
  \*******************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Listbox": () => (/* binding */ Listbox)
/* harmony export */ });
/* eslint-disable func-names, import/prefer-default-export */
/*
*   This content is licensed according to the W3C Software License at
*   https://www.w3.org/Consortium/Legal/2015/copyright-software-and-document
*   https://www.w3.org/TR/wai-aria-practices-1.1/examples/listbox/listbox-rearrangeable.html
*/

/**
  * @desc
  *  Key code constants
  */
const KeyCode = {
  BACKSPACE: 8,
  TAB: 9,
  RETURN: 13,
  ESC: 27,
  SPACE: 32,
  PAGE_UP: 33,
  PAGE_DOWN: 34,
  END: 35,
  HOME: 36,
  LEFT: 37,
  UP: 38,
  RIGHT: 39,
  DOWN: 40,
  DELETE: 46,
};

/**
   * @constructor
   *
   * @desc
   *  Listbox object representing the state and interactions for a listbox widget
   *
   * @param listboxNode
   *  The DOM node pointing to the listbox
   */
class Listbox {
  constructor(listboxNode) {
    this.listboxNode = listboxNode;
    this.activeDescendant = this.listboxNode.getAttribute('aria-activedescendant');
    this.multiselectable = this.listboxNode.hasAttribute('aria-multiselectable');
    this.siblingList = null;
    this.moveButton = null;
    this.keysSoFar = '';
    this.registerEvents();
  }
}

/**
   * @desc
   *  Register events for the listbox interactions
   */
Listbox.prototype.registerEvents = function () {
  this.listboxNode.addEventListener('focus', this.setupFocus.bind(this));
  this.listboxNode.addEventListener('keydown', this.checkKeyPress.bind(this));
  this.listboxNode.addEventListener('click', this.checkClickItem.bind(this));
};

/**
   * @desc
   *  If there is no activeDescendant, focus on the first option
   */
Listbox.prototype.setupFocus = function () {
  if (this.activeDescendant) {
    return;
  }

  this.focusFirstItem();
};

/**
   * @desc
   *  Focus on the first option
   */
Listbox.prototype.focusFirstItem = function () {
  const firstItem = this.listboxNode.querySelector('[role="option"]');

  if (firstItem) {
    this.focusItem(firstItem);
  }
};

/**
   * @desc
   *  Focus on the last option
   */
Listbox.prototype.focusLastItem = function () {
  const itemList = this.listboxNode.querySelectorAll('[role="option"]');

  if (itemList.length) {
    this.focusItem(itemList[itemList.length - 1]);
  }
};

/**
   * @desc
   *  Handle various keyboard controls; UP/DOWN will shift focus; SPACE selects
   *  an item.
   *
   * @param evt
   *  The keydown event object
   */
Listbox.prototype.checkKeyPress = function (evt) {
  const key = evt.which || evt.keyCode;
  const itemToFocus = this.findItemToFocus(key);
  let nextItem = document.getElementById(this.activeDescendant);

  if (!nextItem) {
    return;
  }

  switch (key) {
  case KeyCode.UP:
  case KeyCode.DOWN:
    evt.preventDefault();
    if (key === KeyCode.UP) {
      nextItem = nextItem.previousElementSibling;
    } else {
      nextItem = nextItem.nextElementSibling;
    }

    if (nextItem) {
      this.focusItem(nextItem);
    }
    break;
  case KeyCode.HOME:
    evt.preventDefault();
    this.focusFirstItem();
    break;
  case KeyCode.END:
    evt.preventDefault();
    this.focusLastItem();
    break;
  case KeyCode.SPACE:
    evt.preventDefault();
    this.toggleSelectItem(nextItem);
    break;
  default:
    if (itemToFocus) {
      this.focusItem(itemToFocus);
    }
    break;
  }
};

Listbox.prototype.findItemToFocus = function (key) {
  const itemList = this.listboxNode.querySelectorAll('[role="option"]');
  const character = String.fromCharCode(key);

  if (!this.keysSoFar) {
    for (let i = 0; i < itemList.length; i += 1) {
      if (itemList[i].getAttribute('id') === this.activeDescendant) {
        this.searchIndex = i;
      }
    }
  }
  this.keysSoFar += character;
  this.clearKeysSoFarAfterDelay();

  let nextMatch = this.findMatchInRange(
    itemList,
    this.searchIndex + 1,
    itemList.length,
  );
  if (!nextMatch) {
    nextMatch = this.findMatchInRange(
      itemList,
      0,
      this.searchIndex,
    );
  }
  return nextMatch;
};

Listbox.prototype.clearKeysSoFarAfterDelay = function () {
  if (this.keyClear) {
    clearTimeout(this.keyClear);
    this.keyClear = null;
  }
  this.keyClear = setTimeout((() => {
    this.keysSoFar = '';
    this.keyClear = null;
  }), 500);
};

Listbox.prototype.findMatchInRange = function (list, startIndex, endIndex) {
  // Find the first item starting with the keysSoFar substring, searching in
  // the specified range of items
  for (let n = startIndex; n < endIndex; n += 1) {
    const label = list[n].innerText;
    if (label && label.toUpperCase().indexOf(this.keysSoFar) === 0) {
      return list[n];
    }
  }
  return null;
};

/**
   * @desc
   *  Check if an item is clicked on. If so, focus on it and select it.
   *
   * @param evt
   *  The click event object
   */
Listbox.prototype.checkClickItem = function (evt) {
  if (evt.target.getAttribute('role') === 'option') {
    this.focusItem(evt.target);
    this.toggleSelectItem(evt.target);
  }
};

/**
   * @desc
   *  Toggle the aria-selected value
   *
   * @param element
   *  The element to select
   */
Listbox.prototype.toggleSelectItem = function (element) {
  if (this.multiselectable && element) {
    element.setAttribute(
      'aria-selected',
      element.getAttribute('aria-selected') === 'true' ? 'false' : 'true',
    );

    if (this.moveButton) {
      if (this.listboxNode.querySelector('[aria-selected="true"]')) {
        this.moveButton.setAttribute('aria-disabled', 'false');
      } else {
        this.moveButton.setAttribute('aria-disabled', 'true');
      }
    }
  }
};

/**
   * @desc
   *  Defocus the specified item
   *
   * @param element
   *  The element to defocus
   */
Listbox.prototype.defocusItem = function (element) {
  if (!element) {
    return;
  }
  if (!this.multiselectable) {
    element.removeAttribute('aria-selected');
  }
  element.classList.remove('focused');
};

/**
   * @desc
   *  Focus on the specified item
   *
   * @param element
   *  The element to focus
   */
Listbox.prototype.focusItem = function (element) {
  this.defocusItem(document.getElementById(this.activeDescendant));
  if (!this.multiselectable) {
    element.setAttribute('aria-selected', 'true');
  }
  element.classList.add('focused');
  this.listboxNode.setAttribute('aria-activedescendant', element.id);
  this.activeDescendant = element.id;

  if (this.listboxNode.scrollHeight > this.listboxNode.clientHeight) {
    const scrollBottom = this.listboxNode.clientHeight + this.listboxNode.scrollTop;
    const elementBottom = element.offsetTop + element.offsetHeight;
    if (elementBottom > scrollBottom) {
      this.listboxNode.scrollTop = elementBottom - this.listboxNode.clientHeight;
    } else if (element.offsetTop < this.listboxNode.scrollTop) {
      this.listboxNode.scrollTop = element.offsetTop;
    }
  }

  if (!this.multiselectable && this.moveButton) {
    this.moveButton.setAttribute('aria-disabled', false);
  }
};

/**
   * @desc
   *  Add the specified items to the listbox. Assumes items are valid options.
   *
   * @param items
   *  An array of items to add to the listbox
   */
Listbox.prototype.addItems = function (items) {
  if (!items || !items.length) {
    return false;
  }

  items.forEach(((item) => {
    this.defocusItem(item);
    this.toggleSelectItem(item);
    this.listboxNode.append(item);
  }));

  if (!this.activeDescendant) {
    this.focusItem(items[0]);
  }
  return true;
};

/**
   * @desc
   *  Remove all of the selected items from the listbox; Removes the focused items
   *  in a single select listbox and the items with aria-selected in a multi
   *  select listbox.
   *
   * @returns items
   *  An array of items that were removed from the listbox
   */
Listbox.prototype.deleteItems = function () {
  let itemsToDelete;

  if (this.multiselectable) {
    itemsToDelete = this.listboxNode.querySelectorAll('[aria-selected="true"]');
  } else if (this.activeDescendant) {
    itemsToDelete = [document.getElementById(this.activeDescendant)];
  }

  if (!itemsToDelete || !itemsToDelete.length) {
    return [];
  }

  itemsToDelete.forEach(((item) => {
    item.remove();

    if (item.id === this.activeDescendant) {
      this.clearActiveDescendant();
    }
  }));
  return itemsToDelete;
};

Listbox.prototype.clearActiveDescendant = function () {
  this.activeDescendant = null;
  this.listboxNode.setAttribute('aria-activedescendant', null);

  if (this.moveButton) {
    this.moveButton.setAttribute('aria-disabled', 'true');
  }
};

/**
   * @desc
   *  Delete the currently selected items and add them to the sibling list.
   */
Listbox.prototype.moveItems = function () {
  if (!this.siblingList) {
    return;
  }

  const itemsToMove = this.deleteItems();
  this.siblingList.addItems(itemsToMove);
};

Listbox.prototype.moveAllItems = function () {
  if (!this.siblingList) {
    return;
  }

  const optionsList = this.listboxNode.querySelectorAll('[role="option"]');
  if (optionsList.length) {
    optionsList.forEach((optionElement) => {
      optionElement.setAttribute('aria-selected', 'true');
    });
  }

  const itemsToMove = this.deleteItems();
  this.siblingList.addItems(itemsToMove);
};

/**
   * @desc
   *  Enable Move controls. Moving removes selected items from the current
   *  list and adds them to the sibling list.
   *
   * @param button
   *   Move button to trigger delete
   *
   * @param siblingList
   *   Listbox to move items to
   */
Listbox.prototype.setupMove = function (button, siblingList) {
  this.siblingList = siblingList;
  this.moveButton = button;
  button.addEventListener('click', this.moveItems.bind(this));
};

Listbox.prototype.setupMoveAll = function (button, siblingList) {
  this.siblingList = siblingList;
  this.moveButton = button;
  button.addEventListener('click', this.moveAllItems.bind(this));
};


/***/ }),

/***/ "./src/common/lib/string-format.js":
/*!*****************************************!*\
  !*** ./src/common/lib/string-format.js ***!
  \*****************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const FORMAT_TYPE = {
  CAMEL_CASE: 'CAMEL_CASE',
  UPPER_CAMEL_CASE: 'UPPER_CAMEL_CASE',
  HYPHEN_CASE: 'HYPHEN_CASE',
  UNDER_SCORE_CASE: 'UNDER_SCORE_CASE',
};

function replaceSpecialChar(string, replaceWith) {
  return string.replace(/[^a-zA-Z0-9]/g, replaceWith);
}

function removeFirstCharIfItIsSpecialChar(string) {
  return replaceSpecialChar(string.charAt(0), '') + string.slice(1);
}

function removeLastCharIfItIsSpecialChar(string) {
  return string.slice(0, -1) + replaceSpecialChar(string.slice(-1), '');
}

function capitalize(string) {
  return string.charAt(0).toUpperCase() + string.toLowerCase().slice(1);
}

function toCamelCase(string) {
  let result = replaceSpecialChar(string, ' ');
  result = result.toLowerCase();
  result = result.split(' ').reduce((r, w) => r + capitalize(w));
  result = result.charAt(0).toLowerCase() + result.slice(1);
  return result;
}

function toUpperCamelCase(string) {
  let result = toCamelCase(string);
  result = result.charAt(0).toUpperCase() + result.slice(1);
  return result;
}

function toHyphenCase(string) {
  let result = replaceSpecialChar(string, '-');
  result = removeFirstCharIfItIsSpecialChar(result);
  result = removeLastCharIfItIsSpecialChar(result);
  result = result.toLowerCase();
  return result;
}

function toUnderScoreCase(string) {
  let result = replaceSpecialChar(string, '_');
  result = removeFirstCharIfItIsSpecialChar(result);
  result = removeLastCharIfItIsSpecialChar(result);
  result = result.toUpperCase();
  return result;
}

function toFormat(string, formatType) {
  switch (formatType) {
  case FORMAT_TYPE.CAMEL_CASE:
    return toCamelCase(string);
  case FORMAT_TYPE.UPPER_CAMEL_CASE:
    return toUpperCamelCase(string);
  case FORMAT_TYPE.UNDER_SCORE_CASE:
    return toUnderScoreCase(string);
  case FORMAT_TYPE.HYPHEN_CASE:
    return toHyphenCase(string);
  default:
    return string;
  }
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  toFormat,
  FORMAT_TYPE,
});


/***/ }),

/***/ "./src/common/panel/element-details.js":
/*!*********************************************!*\
  !*** ./src/common/panel/element-details.js ***!
  \*********************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../lib/dom-element/elements.js */ "./src/common/lib/dom-element/elements.js");
/* harmony import */ var _config_element_type_config_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../config/element-type-config.js */ "./src/common/config/element-type-config.js");
/* harmony import */ var _config_element_actions_config_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../config/element-actions-config.js */ "./src/common/config/element-actions-config.js");
/* harmony import */ var _config_element_verification_config_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../config/element-verification-config.js */ "./src/common/config/element-verification-config.js");
/* harmony import */ var _config_html_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../config/html.js */ "./src/common/config/html.js");
/* harmony import */ var _lib_listbox_listbox_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../lib/listbox/listbox.js */ "./src/common/lib/listbox/listbox.js");
/* harmony import */ var _config_locators_config_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../config/locators-config.js */ "./src/common/config/locators-config.js");
/* harmony import */ var _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./panel.elements.js */ "./src/common/panel/panel.elements.js");
/* harmony import */ var _lib_string_format_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../lib/string-format.js */ "./src/common/lib/string-format.js");
/* harmony import */ var _lib_dom_element_element_notify_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../lib/dom-element/element-notify.js */ "./src/common/lib/dom-element/element-notify.js");











const { NOTIFY_RESPONSE } = _lib_dom_element_element_notify_js__WEBPACK_IMPORTED_MODULE_9__["default"];

const ERROR_MESSAGE = {
  NO_LOCATOR: 'Enter value for selected locator type',
  NO_ACTIONS: 'Atleast one action is required',
  NAME_EXISTS: 'Name already exists',
};

const { VALID_ELEMENT_TYPE } = _config_element_type_config_js__WEBPACK_IMPORTED_MODULE_1__["default"];
const { LOCATOR_TYPE } = _config_locators_config_js__WEBPACK_IMPORTED_MODULE_6__["default"];
const { ELEMENT_TYPE_ACTIONS_MAPPING } = _config_element_actions_config_js__WEBPACK_IMPORTED_MODULE_2__["default"];
const { ELEMENT_TYPE_VERIFICATION_MAPPING } = _config_element_verification_config_js__WEBPACK_IMPORTED_MODULE_3__["default"];
// initate list boxes
const actionsListBox = new _lib_listbox_listbox_js__WEBPACK_IMPORTED_MODULE_5__.Listbox(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].listBoxActionsList);
const actionsSelectedListBox = new _lib_listbox_listbox_js__WEBPACK_IMPORTED_MODULE_5__.Listbox(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].listBoxActionsSelected);
const verificationListBox = new _lib_listbox_listbox_js__WEBPACK_IMPORTED_MODULE_5__.Listbox(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].listBoxVerificationList);
const verificationsSelectedListBox = new _lib_listbox_listbox_js__WEBPACK_IMPORTED_MODULE_5__.Listbox(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].listBoxVerificationSelected);

let elementEditInProgress = null;

function hideAddElementButtons() {
  _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].buttonClearElement.hidden = true;
  _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].buttonAddElement.hidden = true;
}

function hideUpdateElementButtons() {
  _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].buttonCancelUpdateElement.hidden = true;
  _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].buttonUpdateElement.hidden = true;
}

function unHideAddElementButtons() {
  _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].buttonClearElement.hidden = false;
  _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].buttonAddElement.hidden = false;
}

function unHideUpdateElementButtons() {
  _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].buttonCancelUpdateElement.hidden = false;
  _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].buttonUpdateElement.hidden = false;
}

function enableUpdateButtons() {
  hideAddElementButtons();
  unHideUpdateElementButtons();
}

function enableAddButtons() {
  hideUpdateElementButtons();
  unHideAddElementButtons();
}

function getElementEditInProgress() {
  return elementEditInProgress;
}

function setElementEditInProgress(elementName) {
  elementEditInProgress = elementName || null;
}

function resetElementEditInProgress() {
  elementEditInProgress = null;
}

function getValueElementName() {
  return _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textBoxElementName.value || '';
}

function isElementNameEmpty() {
  return _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].isEmptyField(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textBoxElementName);
}

function resetElementName() {
  _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].resetElementValue(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textBoxElementName);
}

function resetElementNameError() {
  _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].removeInputError(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textBoxElementName);
}

function showNoInputErrorElementName() {
  _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].showNoInputError(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textBoxElementName);
}

function showElementNameExistsError() {
  _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].showInputError(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textBoxElementName, ERROR_MESSAGE.NAME_EXISTS);
}

function setElementName(elementName) {
  resetElementNameError();
  resetElementName();
  _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textBoxElementName.value = elementName;
}

function loadActionsListBoxOptions(elementType) {
  _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].loadListBoxOptions(
    _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].listBoxActionsList,
    ELEMENT_TYPE_ACTIONS_MAPPING[elementType],
  );
}

/**
 * Will setup move buttons between actions select and selected list box
 */
function setupActionsListBox() {
  actionsListBox.setupMove(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].buttonAddActions, actionsSelectedListBox);
  actionsSelectedListBox.setupMove(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].buttonRemoveActions, actionsListBox);
  actionsListBox.setupMoveAll(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].buttonAddAllActions, actionsSelectedListBox);
  actionsSelectedListBox.setupMoveAll(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].buttonRemoveAllActions, actionsListBox);
}

/**
 * * get all the actions options selected
 * @returns selected items seperated by comma
 */
function getValueActions() {
  return _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].getListBoxItems(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].listBoxActionsSelected).join();
}

function isActionsValueEmpty() {
  return !getValueActions();
}

function resetActions() {
  _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].resetListBoxOptions(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].listBoxActionsList);
  _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].resetListBoxOptions(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].listBoxActionsSelected);
}

function resetActionsError() {
  _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].removeInputError(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].areaActionsList);
}

/**
 * Select Actions by default
 * @param {*} actionsList to be selected
 */
function selectActions(actionsList) {
  actionsList.forEach((action) => {
    if (action) {
      const element = document.getElementById(action);
      actionsSelectedListBox.toggleSelectItem(element);
    }
  });
  _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].buttonAddActions.click();
}

function showNoInputErrorActions() {
  _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].showNoInputError(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].areaActionsList, ERROR_MESSAGE.NO_ACTIONS);
}

function loadVerificationListBoxOptions(elementType) {
  _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].loadListBoxOptions(
    _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].listBoxVerificationList,
    ELEMENT_TYPE_VERIFICATION_MAPPING[elementType],
  );
}

/**
 * Will setup move buttons between verification select and selected list box
 */
function setupVerificationListBox() {
  verificationListBox.setupMove(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].buttonAddVerifications, verificationsSelectedListBox);
  verificationListBox.setupMoveAll(
    _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].buttonAddAllVerifications,
    verificationsSelectedListBox,
  );
  verificationsSelectedListBox.setupMove(
    _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].buttonRemoveVerifications,
    verificationListBox,
  );
  verificationsSelectedListBox.setupMoveAll(
    _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].buttonRemoveAllVerifications,
    verificationListBox,
  );
}

/**
 * get all the verification options selected
 * @returns selected items seperated by comma
 */
function getValueVerifications() {
  return _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].getListBoxItems(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].listBoxVerificationSelected).join();
}

function resetVerifications() {
  _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].resetListBoxOptions(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].listBoxVerificationList);
  _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].resetListBoxOptions(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].listBoxVerificationSelected);
}

function loadActionsAndVerificationOptions(elementType) {
  loadActionsListBoxOptions(elementType);
  loadVerificationListBoxOptions(elementType);
}

function resetActionsAndVerifications() {
  resetActions();
  resetVerifications();
}

/**
 * select Verification by default
 * @param {*} VerificationsList to be selected
 */
function selectVerifications(VerificationsList) {
  VerificationsList.forEach((verification) => {
    if (verification) {
      const element = document.getElementById(verification);
      verificationsSelectedListBox.toggleSelectItem(element);
    }
  });
  _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].buttonAddVerifications.click();
}

/**
 * Load Element Type options from config
 */
function loadElementTypeOptions() {
  Object.entries(VALID_ELEMENT_TYPE).forEach(([, value]) => {
    const optionTag = document.createElement(_config_html_js__WEBPACK_IMPORTED_MODULE_4__["default"].TAGS.option);
    optionTag.value = value;
    optionTag.text = value;
    _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].dropDownElementType.appendChild(optionTag);
  });
}

function getValueElementType() {
  return _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].dropDownElementType.value || '';
}

function isElementTypeEmpty() {
  return _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].isEmptyField(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].dropDownElementType);
}

function resetElementType() {
  _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].resetElementValue(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].dropDownElementType);
}

function resetElementTypeError() {
  _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].removeInputError(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].dropDownElementType);
}

function showNoInputErrorElementType() {
  _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].showNoInputError(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].dropDownElementType);
}

function setElementType(elementType) {
  resetActionsAndVerifications();
  resetElementTypeError();
  resetElementType();
  if (Object.values(VALID_ELEMENT_TYPE).includes(elementType)) {
    _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].dropDownElementType.value = elementType;
    loadActionsAndVerificationOptions(elementType);
  } else {
    showNoInputErrorElementType();
  }
}

function resetInvalidLocatorError() {
  _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].removeInputError(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorByCss);
  _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].removeInputError(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorById);
  _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].removeInputError(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorByName);
  _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].removeInputError(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorByXpath);
}

function resetLocatorWarnings() {
  _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].resetMultiLocatorWarning(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorByName);
  _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].resetMultiLocatorWarning(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorByXpath);
  _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].resetMultiLocatorWarning(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorById);
  _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].resetMultiLocatorWarning(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorByCss);
}

function resetLocatorsError() {
  _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].removeInputError(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].areaLocators);
  resetInvalidLocatorError();
  resetLocatorWarnings();
}

function resetLocators() {
  _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].radioLocatorByXpath.checked = true;
  resetLocatorsError();
  _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].resetElementValue(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorByCss);
  _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].resetElementValue(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorById);
  _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].resetElementValue(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorByName);
  _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].resetElementValue(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorByXpath);
}

function showNoInputErrorLocators() {
  _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].showNoInputError(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].areaLocators, ERROR_MESSAGE.NO_LOCATOR);
}

function getValueLocatorType() {
  const locatorType = _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].getSelectedRadioButton('locatorType');
  return locatorType || '';
}

function setElementLocatorType(locatorType) {
  resetLocators();
  switch (locatorType) {
  case LOCATOR_TYPE.id:
    _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].radioLocatorById.checked = true;
    break;
  case LOCATOR_TYPE.name:
    _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].radioLocatorByName.checked = true;
    break;
  case LOCATOR_TYPE.xpath:
    _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].radioLocatorByXpath.checked = true;
    break;
  case LOCATOR_TYPE.css:
    _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].radioLocatorByCss.checked = true;
    break;
  default:
    break;
  }
}

function getValueLocator() {
  let result;
  switch (getValueLocatorType()) {
  case LOCATOR_TYPE.id:
    result = _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorById.value || '';
    break;
  case LOCATOR_TYPE.name:
    result = _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorByName.value || '';
    break;
  case LOCATOR_TYPE.xpath:
    result = _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorByXpath.value || '';
    break;
  case LOCATOR_TYPE.css:
    result = _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorByCss.value || '';
    break;
  default:
    result = '';
    break;
  }

  return result.trim();
}

function isLocatorValueEmpty() {
  return !getValueLocator();
}

/**
 * To store all the locator values
 * @returns object of locator type value
 */
function getLocators() {
  return {
    [LOCATOR_TYPE.id]: _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorById.value || '',
    [LOCATOR_TYPE.name]: _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorByName.value || '',
    [LOCATOR_TYPE.xpath]: _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorByXpath.value || '',
    [LOCATOR_TYPE.css]: _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorByCss.value || '',
  };
}

function showInvalidLocatorError() {
  switch (getValueLocatorType()) {
  case LOCATOR_TYPE.id:
    _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].showInvalidLocatorError(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorById);
    break;
  case LOCATOR_TYPE.name:
    _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].showInvalidLocatorError(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorByName);
    break;
  case LOCATOR_TYPE.xpath:
    _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].showInvalidLocatorError(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorByXpath);
    break;
  case LOCATOR_TYPE.css:
    _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].showInvalidLocatorError(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorByCss);
    break;
  default:
    break;
  }
}

function showMultiLocator() {
  switch (getValueLocatorType()) {
  case LOCATOR_TYPE.id:
    _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].showMultiLocatorWarning(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorById);
    break;
  case LOCATOR_TYPE.name:
    _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].showMultiLocatorWarning(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorByName);
    break;
  case LOCATOR_TYPE.xpath:
    _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].showMultiLocatorWarning(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorByXpath);
    break;
  case LOCATOR_TYPE.css:
    _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].showMultiLocatorWarning(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorByCss);
    break;
  default:
    break;
  }
}

function validateLocatorResponse(response) {
  resetLocatorWarnings();
  resetInvalidLocatorError();
  if (response === NOTIFY_RESPONSE.multiElement) {
    showMultiLocator();
  } else if (response === NOTIFY_RESPONSE.invalid) {
    showInvalidLocatorError();
  }
}

function resetElementErrors() {
  resetElementNameError();
  resetElementTypeError();
  resetLocatorsError();
  resetActionsError();
}

function resetElementFields() {
  resetElementEditInProgress();
  resetElementName();
  resetElementType();
  resetLocators();
  resetActionsAndVerifications();
  enableAddButtons();
}

function setElementLocatorById(locatorById) {
  _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorById.value = locatorById || '';
}

function setElementLocatorByName(locatorByName, isMultiLocatorName) {
  if (isMultiLocatorName && locatorByName) {
    _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].showMultiLocatorWarning(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorByName);
  }
  _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorByName.value = locatorByName || '';
}

function setElementLocatorByXpath(locatorByXpath, isMultiLocatorXpath) {
  if (isMultiLocatorXpath && locatorByXpath) {
    _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].showMultiLocatorWarning(_panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorByXpath);
  }
  _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorByXpath.value = locatorByXpath || '';
}

function setElementLocatorByCss(locatorByCss) {
  _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorByCss.value = locatorByCss || '';
}

function setElementDetails(element) {
  resetElementFields();
  resetElementErrors();

  setElementName(
    _lib_string_format_js__WEBPACK_IMPORTED_MODULE_8__["default"].toFormat(element.elementName, _lib_string_format_js__WEBPACK_IMPORTED_MODULE_8__["default"].FORMAT_TYPE.UPPER_CAMEL_CASE),
  );
  setElementType(element.elementType);
  setElementLocatorById(element.locatorById);
  setElementLocatorByName(element.locatorByName, element.isMultiLocatorName);
  setElementLocatorByXpath(element.locatorByXpath, element.isMultiLocatorXpath);
  setElementLocatorByCss(element.locatorByCss);
}

function isValidElementDetails() {
  let isValid = true;

  if (isElementNameEmpty()) {
    showNoInputErrorElementName();
    isValid = false;
  }
  if (isElementTypeEmpty()) {
    showNoInputErrorElementType();
    isValid = false;
  }
  if (isLocatorValueEmpty()) {
    showNoInputErrorLocators();
    isValid = false;
  }
  if (isActionsValueEmpty()) {
    showNoInputErrorActions();
    isValid = false;
  }
  return isValid;
}

function onChangeElementName() {
  _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textBoxElementName.onchange = () => {
    if (isElementNameEmpty()) {
      showNoInputErrorElementName();
    } else {
      resetElementNameError();
    }
  };
}

function onChangeElementType() {
  _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].dropDownElementType.onchange = () => {
    resetActionsAndVerifications();
    const elementType = getValueElementType();
    if (elementType) {
      resetElementTypeError();
      loadActionsAndVerificationOptions(elementType);
    } else {
      showNoInputErrorElementType();
    }
  };
}

function onClickActionsSelect() {
  [
    _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].buttonAddAllActions,
    _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].buttonAddActions,
    _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].buttonRemoveActions,
    _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].buttonRemoveAllActions,
  ].forEach((element) => {
    element.addEventListener('click', () => {
      const optionsLength = getValueActions();
      if (optionsLength) {
        resetActionsError();
      }
    });
  });
}

function onChangeLocators() {
  [
    _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].radioLocatorByCss,
    _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].radioLocatorById,
    _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].radioLocatorByName,
    _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].radioLocatorByXpath,
    _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorByCss,
    _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorById,
    _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorByName,
    _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].textboxElementLocatorByXpath,
  ].forEach((element) => {
    element.addEventListener('change', () => {
      if (getValueLocator()) {
        resetLocatorsError();
      } else {
        resetLocatorsError();
        showNoInputErrorLocators();
      }
    });
  });
}

function onClickClearButton() {
  _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].buttonClearElement.onclick = () => {
    resetElementFields();
    resetElementErrors();
  };
}

function onClickCancelButton() {
  _panel_elements_js__WEBPACK_IMPORTED_MODULE_7__["default"].buttonCancelUpdateElement.onclick = () => {
    resetElementFields();
    resetElementErrors();
    enableAddButtons();
  };
}

function setupEventListeners() {
  onClickClearButton();
  onClickCancelButton();
  onClickActionsSelect();
  onChangeElementName();
  onChangeElementType();
  onChangeLocators();
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  enableAddButtons,
  enableUpdateButtons,
  getElementEditInProgress,
  getLocators,
  getValueActions,
  getValueElementName,
  getValueElementType,
  getValueLocator,
  getValueLocatorType,
  getValueVerifications,
  isValidElementDetails,
  isLocatorValueEmpty,
  loadElementTypeOptions,
  resetElementErrors,
  resetElementFields,
  selectActions,
  selectVerifications,
  setupActionsListBox,
  setElementDetails,
  setElementEditInProgress,
  setElementName,
  setElementLocatorType,
  setElementLocatorByCss,
  setElementLocatorById,
  setElementLocatorByName,
  setElementLocatorByXpath,
  setElementType,
  setupEventListeners,
  setupVerificationListBox,
  showElementNameExistsError,
  showNoInputErrorLocators,
  resetLocatorsError,
  validateLocatorResponse,
  resetActionsAndVerifications,
});


/***/ }),

/***/ "./src/common/panel/element-table.js":
/*!*******************************************!*\
  !*** ./src/common/panel/element-table.js ***!
  \*******************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _element_details_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./element-details.js */ "./src/common/panel/element-details.js");
/* harmony import */ var _config_html_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../config/html.js */ "./src/common/config/html.js");
/* harmony import */ var _panel_elements_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./panel.elements.js */ "./src/common/panel/panel.elements.js");
/* harmony import */ var _config_locators_config_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../config/locators-config.js */ "./src/common/config/locators-config.js");
/* harmony import */ var _page_details_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./page-details.js */ "./src/common/panel/page-details.js");






const table = _panel_elements_js__WEBPACK_IMPORTED_MODULE_2__["default"].tableRecordedElements;
const { LOCATOR_TYPE } = _config_locators_config_js__WEBPACK_IMPORTED_MODULE_3__["default"];

const COLUMN_NAME = {
  name: 'Name',
  type: 'Type',
  identifier: 'Identifier',
  locator: 'Locator',
  actions: 'Actions',
  verifications: 'Verifications',
  allLocators: 'AllLocators',
  buttons: 'Buttons',
};

const COLUMN_ORDER = Array.from(new Set([
  COLUMN_NAME.name,
  COLUMN_NAME.type,
  COLUMN_NAME.identifier,
  COLUMN_NAME.locator,
  COLUMN_NAME.actions,
  COLUMN_NAME.verifications,
  COLUMN_NAME.allLocators,
  COLUMN_NAME.buttons,
]));

function deleteRowButton() {
  const buttonElement = document.createElement(_config_html_js__WEBPACK_IMPORTED_MODULE_1__["default"].TAGS.a);
  buttonElement.innerHTML = 'X';
  buttonElement.classList.add('remove-button');
  buttonElement.setAttribute('role', 'button');
  buttonElement.setAttribute('href', '#');
  buttonElement.setAttribute('name', _panel_elements_js__WEBPACK_IMPORTED_MODULE_2__["default"].buttonDeleteRecordName);
  return buttonElement;
}

function calling(rowDetails) {
  // eslint-disable-next-line no-use-before-define
  editElement(getRowNumber(rowDetails));
}

function insertNewRow(rowNumber = -1) {
  const row = table.insertRow(rowNumber);
  row.addEventListener('click', calling.bind(null, row));
  COLUMN_ORDER.forEach(async (value, index) => {
    await row.insertCell(index);
  });
  return row;
}

function getColumnIndex(name) {
  return COLUMN_ORDER.indexOf(name);
}

function getRowsCount() {
  return table.rows.length;
}

function getRowNumber(row) {
  return row.rowIndex - 1; // rowindex start from 1 for tbody
}

function deleteRow(rowNumber) {
  if (rowNumber > -1) {
    table.deleteRow(rowNumber);
  }
}

function insertDeleteButton(rowNumber) {
  table.rows[rowNumber].cells[getColumnIndex(COLUMN_NAME.buttons)]
    .appendChild(deleteRowButton());
}

function hideAllLocatorsCell(rowNumber) {
  table.rows[rowNumber].cells[getColumnIndex(COLUMN_NAME.allLocators)].style.display = 'none';
}

function setElementName(rowNumber, elementName) {
  const cellData = elementName || _element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].getValueElementName();
  const elm = table.rows[rowNumber].cells[getColumnIndex(COLUMN_NAME.name)];
  elm.innerHTML = cellData;
  elm.setAttribute('name', cellData);
  elm.classList.add('tooltiptext');
}

function getElementName(rowNumber) {
  return table.rows[rowNumber].cells[getColumnIndex(COLUMN_NAME.name)].innerHTML;
}

function getElementNameList() {
  const result = [];
  for (let rowNumber = 0; rowNumber < getRowsCount(); rowNumber += 1) {
    result.push(table.rows[rowNumber].cells[0].innerHTML);
  }
  return result;
}

function isElementNameExists() {
  const name = _element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].getValueElementName();
  return getElementNameList().map((value) => value.toLowerCase()).includes(name.toLowerCase());
}

function isNotRepeatedElement() {
  let isNotRepeated = true;
  if (isElementNameExists()) {
    _element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].showElementNameExistsError();
    isNotRepeated = false;
  }
  return isNotRepeated;
}

function getElementType(rowNumber) {
  return table.rows[rowNumber].cells[getColumnIndex(COLUMN_NAME.type)].innerHTML;
}

function setElementType(rowNumber, elementType) {
  table.rows[rowNumber].cells[getColumnIndex(COLUMN_NAME.type)]
    .innerHTML = elementType || _element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].getValueElementType();
}

function getLocatorType(rowNumber) {
  return table.rows[rowNumber].cells[getColumnIndex(COLUMN_NAME.identifier)].innerHTML;
}

function setLocatorType(rowNumber, locatorType) {
  table.rows[rowNumber].cells[getColumnIndex(COLUMN_NAME.identifier)]
    .innerHTML = locatorType || _element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].getValueLocatorType();
}

function getLocator(rowNumber) {
  return table.rows[rowNumber].cells[getColumnIndex(COLUMN_NAME.locator)].innerHTML;
}

function setLocator(rowNumber, locator) {
  const cellData = locator || _element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].getValueLocator();
  const elm = table.rows[rowNumber].cells[getColumnIndex(COLUMN_NAME.locator)];
  elm.innerHTML = cellData;
  elm.setAttribute('name', cellData);
  elm.classList.add('tooltiptext');
}

function getAllLocators(rowNumber) {
  return JSON.parse(JSON.stringify(
    table.rows[rowNumber].cells[getColumnIndex(COLUMN_NAME.allLocators)].innerHTML,
  ));
}

function setAllLocators(rowNumber, locators) {
  const locatorList = locators || _element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].getLocators();
  table.rows[rowNumber].cells[getColumnIndex(COLUMN_NAME.allLocators)]
    .innerHTML = JSON.stringify(locatorList);
}

function getActions(rowNumber) {
  return table.rows[rowNumber].cells[getColumnIndex(COLUMN_NAME.actions)].innerHTML;
}

function getActionsList(rowNumber) {
  return getActions(rowNumber).split(',');
}

function setActions(rowNumber, actionTypes) {
  const cellData = actionTypes || _element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].getValueActions();
  const elm = table.rows[rowNumber].cells[getColumnIndex(COLUMN_NAME.actions)];
  elm.innerHTML = cellData;
  elm.setAttribute('name', cellData);
  elm.classList.add('tooltiptext');
}

function getVerifications(rowNumber) {
  return table.rows[rowNumber].cells[getColumnIndex(COLUMN_NAME.verifications)].innerHTML;
}

function getVerificationsList(rowNumber) {
  return getVerifications(rowNumber).split(',');
}

function setVerifications(rowNumber, verificationList) {
  const cellData = verificationList || _element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].getValueVerifications();
  const elm = table.rows[rowNumber].cells[getColumnIndex(COLUMN_NAME.verifications)];
  elm.innerHTML = cellData;
  elm.setAttribute('name', cellData);
  elm.classList.add('tooltiptext');
}

function addElement(rowNumber, item = {}) {
  const locators = item.locatorIdentifierType
    ? { [item.locatorIdentifierType]: item.locatorIdentifierValue } : null;
  insertDeleteButton(rowNumber);
  setElementName(rowNumber, item.elementName);
  setElementType(rowNumber, item.elementType);
  setLocatorType(rowNumber, item.locatorIdentifierType);
  setLocator(rowNumber, item.locatorIdentifierValue);
  setActions(rowNumber, item.elementActionMethods);
  setVerifications(rowNumber, item.elementVerificationMethods);
  setAllLocators(rowNumber, locators);
  hideAllLocatorsCell(rowNumber);
  _element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].resetElementFields();
}

function editElement(rowNumber) {
  const locators = JSON.parse(getAllLocators(rowNumber));
  _element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].setElementEditInProgress(getElementName(rowNumber));
  _element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].setElementName(getElementName(rowNumber));
  _element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].setElementType(getElementType(rowNumber));
  _element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].setElementLocatorType(getLocatorType(rowNumber));
  _element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].setElementLocatorByCss(locators[LOCATOR_TYPE.css]);
  _element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].setElementLocatorById(locators[LOCATOR_TYPE.id]);
  _element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].setElementLocatorByName(locators[LOCATOR_TYPE.name]);
  _element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].setElementLocatorByXpath(locators[LOCATOR_TYPE.xpath]);
  _element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].selectActions(getActionsList(rowNumber));
  _element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].selectVerifications(getVerificationsList(rowNumber));
  _element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].enableUpdateButtons();
}

function updateElement() {
  const elementEditInProgress = _element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementEditInProgress();
  const currentRowNumber = getElementNameList().indexOf(elementEditInProgress);
  deleteRow(currentRowNumber);
  // insert new row same position
  const row = insertNewRow(currentRowNumber);
  const newRowNumber = getRowNumber(row);
  addElement(newRowNumber);
}

function setupClearRecordsClick() {
  _panel_elements_js__WEBPACK_IMPORTED_MODULE_2__["default"].buttonClearRecordedElements.onclick = () => {
    while (getRowsCount() > 0) {
      table.deleteRow(-1); // delete last row
    }
  };
}

// Add new rows in table
function addNewRows(item = null) {
  const row = insertNewRow();
  const rowNumber = getRowNumber(row);
  addElement(rowNumber, item);
}

function setupAddElementClick() {
  // eslint-disable-next-line consistent-return
  _panel_elements_js__WEBPACK_IMPORTED_MODULE_2__["default"].buttonAddElement.onclick = () => {
    _element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].resetElementErrors();
    if (_page_details_js__WEBPACK_IMPORTED_MODULE_4__["default"].isNotValidPageName()) {
      return false;
    }
    if (_element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].isValidElementDetails() && isNotRepeatedElement()) {
      const row = insertNewRow();
      const rowNumber = getRowNumber(row);
      addElement(rowNumber);
    }
  };
}

function setupUpdateElementClick() {
  _panel_elements_js__WEBPACK_IMPORTED_MODULE_2__["default"].buttonUpdateElement.onclick = () => {
    _element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].resetElementErrors();
    if (_element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].isValidElementDetails()) {
      updateElement();
    }
  };
}

function setupRowButtonsClick() {
  table.onclick = () => {
    const { activeElement } = document;
    if (activeElement.name === _panel_elements_js__WEBPACK_IMPORTED_MODULE_2__["default"].buttonDeleteRecordName) {
      table.deleteRow(getRowNumber(activeElement.parentElement.parentElement));
      _panel_elements_js__WEBPACK_IMPORTED_MODULE_2__["default"].buttonClearElement.click();
    }
    if (activeElement.name === _panel_elements_js__WEBPACK_IMPORTED_MODULE_2__["default"].buttonEditRecordName) {
      editElement(getRowNumber(activeElement.parentElement.parentElement));
    }
    return false; // to disable auto scrolling of link
  };
}

function setupEventListeners() {
  setupAddElementClick();
  setupClearRecordsClick();
  setupRowButtonsClick();
  setupUpdateElementClick();
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  getActions,
  getElementName,
  getElementType,
  getLocator,
  getLocatorType,
  getVerifications,
  getRowsCount,
  setupEventListeners,
  addNewRows,
  getAllLocators,
});


/***/ }),

/***/ "./src/common/panel/page-details.js":
/*!******************************************!*\
  !*** ./src/common/panel/page-details.js ***!
  \******************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../lib/dom-element/elements.js */ "./src/common/lib/dom-element/elements.js");
/* harmony import */ var _panel_elements_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./panel.elements.js */ "./src/common/panel/panel.elements.js");
/* harmony import */ var _config_web_config_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../config/web-config.js */ "./src/common/config/web-config.js");




const { EVENT_TYPE } = _config_web_config_js__WEBPACK_IMPORTED_MODULE_2__["default"];

function getName() {
  return _panel_elements_js__WEBPACK_IMPORTED_MODULE_1__["default"].textBoxPageName.value || '';
}

function getParentClassName() {
  return _panel_elements_js__WEBPACK_IMPORTED_MODULE_1__["default"].textBoxPageParentClass.value || '';
}

function getChildClassName() {
  return _panel_elements_js__WEBPACK_IMPORTED_MODULE_1__["default"].textBoxPageChildClass.value || '';
}

function getOperation() {
  return _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].getSelectedRadioButton(_panel_elements_js__WEBPACK_IMPORTED_MODULE_1__["default"].radioPageOperationGroupName);
}

function showNoInputErrorName() {
  _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].showNoInputError(_panel_elements_js__WEBPACK_IMPORTED_MODULE_1__["default"].textBoxPageName);
}

function resetNameError() {
  _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].removeInputError(_panel_elements_js__WEBPACK_IMPORTED_MODULE_1__["default"].textBoxPageName);
}

function isPageNameEmpty() {
  return _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].isEmptyField(_panel_elements_js__WEBPACK_IMPORTED_MODULE_1__["default"].textBoxPageName);
}

function isNotValidPageName() {
  if (isPageNameEmpty()) {
    _lib_dom_element_elements_js__WEBPACK_IMPORTED_MODULE_0__["default"].showNoInputError(_panel_elements_js__WEBPACK_IMPORTED_MODULE_1__["default"].textBoxPageName);
    _panel_elements_js__WEBPACK_IMPORTED_MODULE_1__["default"].textBoxPageName.focus();
    return true;
  }
  return false;
}

function setupNameChangeEventListeners() {
  _panel_elements_js__WEBPACK_IMPORTED_MODULE_1__["default"].textBoxPageName.addEventListener(EVENT_TYPE.change, () => {
    if (getName()) {
      resetNameError();
    } else {
      showNoInputErrorName();
    }
  });
}

function setupEventListeners() {
  setupNameChangeEventListeners();
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  getChildClassName,
  getName,
  getOperation,
  getParentClassName,
  setupEventListeners,
  isNotValidPageName,
});


/***/ }),

/***/ "./src/common/panel/panel.elements.js":
/*!********************************************!*\
  !*** ./src/common/panel/panel.elements.js ***!
  \********************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  radioPageOperationGroupName: 'operationType',

  radioPageOperationCreate: document.getElementById('radioOperationCreate'),

  radioPageOperationUpdate: document.getElementById('radioOperationUpdate'),

  buttonDownloadPomJson: document.getElementById('downloadPomJson'),

  fileUploadPomJson: document.getElementById('fileUpload'),
  buttonUploadPomJson: document.getElementById('buttonUpload'),

  textBoxPageName: document.getElementById('pageName'),

  textBoxPageParentClass: document.getElementById('pageParentClass'),

  textBoxPageChildClass: document.getElementById('pageChildClass'),

  textBoxElementName: document.getElementById('elementName'),

  dropDownElementType: document.getElementById('elementType'),

  areaLocators: document.getElementById('locator-area'),

  radioLocatorById: document.getElementById('radioLocatorById'),

  radioLocatorByName: document.getElementById('radioLocatorByName'),

  radioLocatorByXpath: document.getElementById('radioLocatorByXpath'),

  radioLocatorByCss: document.getElementById('radioLocatorByCss'),

  textboxElementLocatorById: document.getElementById('locatorById'),

  textboxElementLocatorByName: document.getElementById('locatorByName'),

  textboxElementLocatorByXpath: document.getElementById('locatorByXpath'),

  textboxElementLocatorByCss: document.getElementById('locatorByCss'),

  buttonSpy: document.getElementById('spyElement'),

  areaActionsList: document.getElementById('action-area'),

  listBoxActionsList: document.getElementById('actionsList'),

  listBoxActionsSelected: document.getElementById('actionsSelected'),

  buttonAddActions: document.getElementById('addSelectedActions'),

  buttonAddAllActions: document.getElementById('addAllActions'),

  buttonRemoveActions: document.getElementById('removeSelectedActions'),

  buttonRemoveAllActions: document.getElementById('removeAllActions'),

  areaVerificationList: document.getElementById('verfication-area'),

  listBoxVerificationList: document.getElementById('verificationList'),

  listBoxVerificationSelected: document.getElementById('verificationsSelected'),

  buttonAddVerifications: document.getElementById('addSelectedVerifications'),

  buttonAddAllVerifications: document.getElementById('addAllVerifications'),

  buttonRemoveVerifications: document.getElementById('removeSelectedVerifications'),

  buttonRemoveAllVerifications: document.getElementById('removeAllVerifications'),

  buttonAddElement: document.getElementById('addElement'),

  buttonClearElement: document.getElementById('clearElement'),

  buttonCancelUpdateElement: document.getElementById('cancelUpdate'),

  buttonUpdateElement: document.getElementById('updateElement'),

  tableRecordedElements: document.getElementById('RecordedElementsTable'),

  buttonClearRecordedElements: document.getElementById('deleteAllRecordedElement'),

  buttonDeleteRecordName: 'deleteRecordedElement',

  buttonEditRecordName: 'editRecordedElement',
});


/***/ }),

/***/ "./src/common/panel/pom-json.js":
/*!**************************************!*\
  !*** ./src/common/panel/pom-json.js ***!
  \**************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _page_details_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./page-details.js */ "./src/common/panel/page-details.js");
/* harmony import */ var _element_table_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./element-table.js */ "./src/common/panel/element-table.js");
/* harmony import */ var _config_pomMaster_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../config/pomMaster.js */ "./src/common/config/pomMaster.js");




class PomJson {
  constructor() {
    this._pomJson = JSON.parse(JSON.stringify(_config_pomMaster_js__WEBPACK_IMPORTED_MODULE_2__.pomMasterJSON));
    this._locatorsJson = JSON.parse(JSON.stringify(_config_pomMaster_js__WEBPACK_IMPORTED_MODULE_2__.locatorsMasterJson));
  }

  getFileName() {
    return `${this._pomJson[0].pageName}.json`;
  }

  getlocatorsJson() {
    return this._locatorsJson;
  }

  getPomJson() {
    return this._pomJson;
  }

  resetLocator(pageIndex = 0) {
    this._pomJson[pageIndex].locators = [];
  }

  updatePageName(pageName, pageIndex = 0) {
    this._pomJson[pageIndex].pageName = pageName;
  }

  updatePageOperation(operation, pageIndex = 0) {
    this._pomJson[pageIndex].operation = operation;
  }

  updateParentClass(parentClassName, pageIndex = 0) {
    this._pomJson[pageIndex].parentClassName = parentClassName;
  }

  updateChildClass(childClassName, pageIndex = 0) {
    this._pomJson[pageIndex].childClassNames = childClassName;
  }

  addLocator(locator, pageIndex = 0) {
    this._pomJson[pageIndex].locators.push(locator);
  }

  updatePageMetaData() {
    this.updatePageOperation((_page_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].getOperation()));
    this.updatePageName(_page_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].getName());
    this.updateParentClass(_page_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].getParentClassName());
    this.updateChildClass(_page_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].getChildClassName());
  }

  addRecordedELements() {
    this.resetLocator();
    for (let rowNumber = 0; rowNumber < _element_table_js__WEBPACK_IMPORTED_MODULE_1__["default"].getRowsCount(); rowNumber += 1) {
      const locator = {};
      Object.assign(locator, this.getlocatorsJson());
      locator.elementName = _element_table_js__WEBPACK_IMPORTED_MODULE_1__["default"].getElementName(rowNumber);
      locator.elementType = _element_table_js__WEBPACK_IMPORTED_MODULE_1__["default"].getElementType(rowNumber);
      locator.locatorIdentifierType = _element_table_js__WEBPACK_IMPORTED_MODULE_1__["default"].getLocatorType(rowNumber);
      locator.locatorIdentifierValue = _element_table_js__WEBPACK_IMPORTED_MODULE_1__["default"].getLocator(rowNumber);
      locator.elementActionMethods = _element_table_js__WEBPACK_IMPORTED_MODULE_1__["default"].getActions(rowNumber);
      locator.elementVerificationMethods = _element_table_js__WEBPACK_IMPORTED_MODULE_1__["default"].getVerifications(rowNumber);
      this.addLocator(locator);
    }
  }
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PomJson);


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/*!*************************************!*\
  !*** ./src/chrome/scripts/panel.js ***!
  \*************************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _common_panel_element_details_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../common/panel/element-details.js */ "./src/common/panel/element-details.js");
/* harmony import */ var _common_panel_page_details_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../common/panel/page-details.js */ "./src/common/panel/page-details.js");
/* harmony import */ var _common_panel_panel_elements_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../common/panel/panel.elements.js */ "./src/common/panel/panel.elements.js");
/* harmony import */ var _common_panel_element_table_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../common/panel/element-table.js */ "./src/common/panel/element-table.js");
/* harmony import */ var _common_panel_pom_json_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../common/panel/pom-json.js */ "./src/common/panel/pom-json.js");
/* harmony import */ var _common_config_web_config_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../common/config/web-config.js */ "./src/common/config/web-config.js");







const { MESSAGE_TYPE } = _common_config_web_config_js__WEBPACK_IMPORTED_MODULE_5__["default"];

const pomJson = new _common_panel_pom_json_js__WEBPACK_IMPORTED_MODULE_4__["default"]();
const mimeTypeJson = 'application/json';

// run when plugin panel is loaded
(function onload() {
  _common_panel_element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].loadElementTypeOptions();
  _common_panel_element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].setupActionsListBox();
  _common_panel_element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].setupVerificationListBox();
  _common_panel_element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].setupEventListeners();
  _common_panel_element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].enableAddButtons();
  _common_panel_page_details_js__WEBPACK_IMPORTED_MODULE_1__["default"].setupEventListeners();
  _common_panel_element_table_js__WEBPACK_IMPORTED_MODULE_3__["default"].setupEventListeners();
}());

/** CHROME INTERACTION METHODS - START */
function downloadPomJson() {
  // get download file contents
  const downloadUrl = window.URL.createObjectURL(new Blob(
    [JSON.stringify(pomJson.getPomJson(), null, 2)],
    { type: mimeTypeJson },
  ));

  // download the file
  chrome.downloads.download({
    url: downloadUrl,
    filename: pomJson.getFileName(_common_panel_page_details_js__WEBPACK_IMPORTED_MODULE_1__["default"].getName()),
  });
}
function populateListInTable(result) {
  // eslint-disable-next-line no-restricted-syntax
  for (const item of result.locators) {
    _common_panel_element_table_js__WEBPACK_IMPORTED_MODULE_3__["default"].addNewRows(item);
  }
}
_common_panel_panel_elements_js__WEBPACK_IMPORTED_MODULE_2__["default"].buttonUploadPomJson.onclick = () => {
  _common_panel_panel_elements_js__WEBPACK_IMPORTED_MODULE_2__["default"].fileUploadPomJson.click();
};

// Upload POM JSon file and read and display in table.
_common_panel_panel_elements_js__WEBPACK_IMPORTED_MODULE_2__["default"].fileUploadPomJson.onchange = () => {
  const file = _common_panel_panel_elements_js__WEBPACK_IMPORTED_MODULE_2__["default"].fileUploadPomJson.files[0];
  const reader = new FileReader();
  reader.onload = (ev) => {
    const locatorList = JSON.parse(ev.target.result);
    if (locatorList[0].locators.length) {
      populateListInTable(locatorList[0]);
    }
    _common_panel_panel_elements_js__WEBPACK_IMPORTED_MODULE_2__["default"].fileUploadPomJson.value = null;
    _common_panel_panel_elements_js__WEBPACK_IMPORTED_MODULE_2__["default"].radioPageOperationUpdate.checked = true;
  };
  reader.readAsText(file);
};

// listener for right click events from webpage - content script
chrome.runtime.onMessage.addListener(
  (request, sender) => {
    if (sender.id === chrome.runtime.id
      && request.method === MESSAGE_TYPE.elementRightClicked) {
      if (request.popupId) {
        chrome.windows.update(request.popupId, { focused: true });
      }
      _common_panel_element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].setElementDetails(request.element);
    }
  },
);

async function getCurrentTab() {
  const queryOptions = { active: true };
  const [tab] = await chrome.tabs.query(queryOptions);
  return tab;
}

/**
 * Send spy element notification to content script in webpage
 * @param {*} locatorType
 * @param {*} locatorValue
 */
function spyElement(locatorType, locatorValue) {
  getCurrentTab().then((tab) => {
    chrome.tabs.sendMessage(
      tab.id,
      {
        method: MESSAGE_TYPE.spyElement,
        locatorType,
        locatorValue,
      },
      (response) => {
        _common_panel_element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].validateLocatorResponse(response);
      },
    );
  });
}
/** CHROME INTERACTION METHODS - END */

/** PANEL USER INTERACTION METHODS - START */

_common_panel_panel_elements_js__WEBPACK_IMPORTED_MODULE_2__["default"].buttonSpy.onclick = () => {
  const locatorType = _common_panel_element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].getValueLocatorType();
  const locatorValue = _common_panel_element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].getValueLocator();

  _common_panel_element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].resetLocatorsError();
  if (_common_panel_element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].isLocatorValueEmpty()) {
    _common_panel_element_details_js__WEBPACK_IMPORTED_MODULE_0__["default"].showNoInputErrorLocators();
  } else {
    spyElement(locatorType, locatorValue);
  }
};

_common_panel_panel_elements_js__WEBPACK_IMPORTED_MODULE_2__["default"].buttonDownloadPomJson.onclick = () => {
  if (_common_panel_page_details_js__WEBPACK_IMPORTED_MODULE_1__["default"].isNotValidPageName()) {
    return false;
  }
  pomJson.updatePageMetaData();
  pomJson.addRecordedELements();
  downloadPomJson();
  return true;
};

/** PANEL USER INTERACTION METHODS - START */

})();

/******/ })()
;
//# sourceMappingURL=panel.js.map