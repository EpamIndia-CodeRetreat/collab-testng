/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/common/config/element-type-config.js":
/*!**************************************************!*\
  !*** ./src/common/config/element-type-config.js ***!
  \**************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _html_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./html.js */ "./src/common/config/html.js");


/**
 * Valid Element Type from Collab framework
 */
const VALID_ELEMENT_TYPE = {
  button: 'Button',
  checkbox: 'CheckBox',
  combobox: 'ComboBox',
  dropdown: 'DropDown',
  image: 'Image',
  iframe: 'iframe',
  link: 'Link',
  label: 'Label',
  textarea: 'TextArea',
  textbox: 'TextBox',
  radio: 'RadioButton',
};

/**
 * Map Element Type based on html tag
 */
const ELEMENT_TAGNAME_MAPPING = {
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.button]: VALID_ELEMENT_TYPE.button,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.h1]: VALID_ELEMENT_TYPE.label,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.h2]: VALID_ELEMENT_TYPE.label,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.h3]: VALID_ELEMENT_TYPE.label,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.h4]: VALID_ELEMENT_TYPE.label,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.h5]: VALID_ELEMENT_TYPE.label,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.iframe]: VALID_ELEMENT_TYPE.iframe,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.img]: VALID_ELEMENT_TYPE.image,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.label]: VALID_ELEMENT_TYPE.label,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.link]: VALID_ELEMENT_TYPE.link,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.p]: VALID_ELEMENT_TYPE.label,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.path]: VALID_ELEMENT_TYPE.image,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.select]: VALID_ELEMENT_TYPE.dropdown,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.svg]: VALID_ELEMENT_TYPE.image,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.textarea]: VALID_ELEMENT_TYPE.textarea,
};

/**
 * Map Element Type based on input tag type
 */
const ELEMENT_INPUT_TYPE_MAPPING = {
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.button]: VALID_ELEMENT_TYPE.button,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.checkbox]: VALID_ELEMENT_TYPE.checkbox,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.color]: VALID_ELEMENT_TYPE.textbox,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.date]: VALID_ELEMENT_TYPE.textbox,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.dateTimeLocal]: VALID_ELEMENT_TYPE.textbox,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.email]: VALID_ELEMENT_TYPE.textbox,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.file]: VALID_ELEMENT_TYPE.button,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.image]: VALID_ELEMENT_TYPE.image,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.month]: VALID_ELEMENT_TYPE.textbox,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.number]: VALID_ELEMENT_TYPE.textbox,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.password]: VALID_ELEMENT_TYPE.textbox,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.radio]: VALID_ELEMENT_TYPE.radio,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.range]: VALID_ELEMENT_TYPE.textbox,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.reset]: VALID_ELEMENT_TYPE.button,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.search]: VALID_ELEMENT_TYPE.textbox,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.submit]: VALID_ELEMENT_TYPE.button,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.tel]: VALID_ELEMENT_TYPE.textbox,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.text]: VALID_ELEMENT_TYPE.textbox,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.time]: VALID_ELEMENT_TYPE.textbox,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.url]: VALID_ELEMENT_TYPE.textbox,
  [_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.week]: VALID_ELEMENT_TYPE.textbox,
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  VALID_ELEMENT_TYPE,
  ELEMENT_TAGNAME_MAPPING,
  ELEMENT_INPUT_TYPE_MAPPING,
});


/***/ }),

/***/ "./src/common/config/html.js":
/*!***********************************!*\
  !*** ./src/common/config/html.js ***!
  \***********************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const TAGS = {
  a: 'A',
  button: 'BUTTON',
  div: 'DIV',
  h1: 'H1',
  h2: 'H2',
  h3: 'H3',
  h4: 'H4',
  h5: 'H5',
  i: 'I',
  input: 'INPUT',
  iframe: 'IFRAME',
  img: 'IMG',
  label: 'LABEL',
  li: 'LI',
  link: 'LINK',
  option: 'OPTION',
  p: 'P',
  path: 'PATH',
  select: 'SELECT',
  span: 'SPAN',
  svg: 'SVG',
  strong: 'STRONG',
  textarea: 'TEXTAREA',
};

const ATTRIBUTES = {
  alt: 'alt',
  ariaLabel: 'aria-label',
  class: 'class',
  dataTestId: 'data-testid',
  href: 'href',
  id: 'id',
  name: 'name',
  role: 'role',
  src: 'src',
  title: 'title',
  type: 'type',
};

/**
 * Input tag types
 */
const INPUT_TYPE = {
  button: 'button',
  checkbox: 'checkbox',
  color: 'color',
  date: 'date',
  dateTimeLocal: 'datetime-local',
  email: 'email',
  file: 'file',
  hidden: 'hidden',
  image: 'image',
  month: 'month',
  number: 'number',
  password: 'password',
  radio: 'radio',
  range: 'range',
  reset: 'reset',
  search: 'search',
  submit: 'submit',
  tel: 'tel',
  text: 'text',
  time: 'time',
  url: 'url',
  week: 'week',
};

const CONTAINER_TAGS = [
  TAGS.span,
  TAGS.div,
  TAGS.p,
  TAGS.i,
  TAGS.li,
  TAGS.strong,
];

const HEADER_TAGS = [
  TAGS.h1,
  TAGS.h2,
  TAGS.h3,
  TAGS.h4,
  TAGS.h5,
];

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  ATTRIBUTES,
  CONTAINER_TAGS,
  HEADER_TAGS,
  INPUT_TYPE,
  TAGS,
});


/***/ }),

/***/ "./src/common/config/locators-config.js":
/*!**********************************************!*\
  !*** ./src/common/config/locators-config.js ***!
  \**********************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const LOCATOR_TYPE = {
  id: 'id',
  name: 'name',
  xpath: 'xpath',
  css: 'css',
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  LOCATOR_TYPE,
});


/***/ }),

/***/ "./src/common/config/web-config.js":
/*!*****************************************!*\
  !*** ./src/common/config/web-config.js ***!
  \*****************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/**
 * Request Message names between plugin and web page content script
 */
const MESSAGE_TYPE = {
  elementRightClicked: 'elementRightClicked',
  spyElement: 'spyElement',
  extensionIsOpen: 'extensionIsOpen',
};

/**
 * DOM element event types
 */
const EVENT_TYPE = {
  contextMenu: 'contextmenu',
  change: 'change',
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  EVENT_TYPE,
  MESSAGE_TYPE,
});


/***/ }),

/***/ "./src/common/lib/dom-element/css/builder-attributes.js":
/*!**************************************************************!*\
  !*** ./src/common/lib/dom-element/css/builder-attributes.js ***!
  \**************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _element_data_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../element-data.js */ "./src/common/lib/dom-element/element-data.js");
/* harmony import */ var _css_selector_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./css-selector.js */ "./src/common/lib/dom-element/css/css-selector.js");
/* eslint-disable func-names */



const byId = function (element) {
  let css = null;
  if (_element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].isHavingIdAttribute(element)) {
    css = _css_selector_js__WEBPACK_IMPORTED_MODULE_1__["default"].byId(element);
  }

  return css;
};

const byClass = function (element) {
  let css = null;
  if (_element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementAttributeClassName(element)) {
    css = `${_css_selector_js__WEBPACK_IMPORTED_MODULE_1__["default"].getTag(element)}${_css_selector_js__WEBPACK_IMPORTED_MODULE_1__["default"].byClassName(element)}`;
  }

  return css;
};

const byName = function (element) {
  let css = null;
  if (_element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].isHavingNameAttribute(element)) {
    css = `${_css_selector_js__WEBPACK_IMPORTED_MODULE_1__["default"].getTag(element)}${_css_selector_js__WEBPACK_IMPORTED_MODULE_1__["default"].byName(element)}`;
  }

  return css;
};

const byDataTestId = function (element) {
  let css = null;
  if (_element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].isHavingDataTestIdAttribute(element)) {
    css = _css_selector_js__WEBPACK_IMPORTED_MODULE_1__["default"].byDataTestId(element);
  }

  return css;
};

const byRole = function (element) {
  let css = null;
  if (_element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementAttributeRole(element)) {
    css = `${_css_selector_js__WEBPACK_IMPORTED_MODULE_1__["default"].getTag(element)}${_css_selector_js__WEBPACK_IMPORTED_MODULE_1__["default"].byRole(element)}`;
  }

  return css;
};

const byTitle = function (element) {
  let css = null;
  if (_element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].isHavingTitleAttribute(element)) {
    css = `${_css_selector_js__WEBPACK_IMPORTED_MODULE_1__["default"].getTag(element)}${_css_selector_js__WEBPACK_IMPORTED_MODULE_1__["default"].byTitle(element)}`;
  }

  return css;
};

const byType = function (element) {
  let css = null;
  if (_element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementAttributeType(element)) {
    css = `${_css_selector_js__WEBPACK_IMPORTED_MODULE_1__["default"].getTag(element)}${_css_selector_js__WEBPACK_IMPORTED_MODULE_1__["default"].byType(element)}`;
  }

  return css;
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  byClass,
  byDataTestId,
  byId,
  byName,
  byRole,
  byTitle,
  byType,
});


/***/ }),

/***/ "./src/common/lib/dom-element/css/builder-image.js":
/*!*********************************************************!*\
  !*** ./src/common/lib/dom-element/css/builder-image.js ***!
  \*********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _element_data_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../element-data.js */ "./src/common/lib/dom-element/element-data.js");
/* harmony import */ var _css_selector_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./css-selector.js */ "./src/common/lib/dom-element/css/css-selector.js");
/* harmony import */ var _config_html_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../config/html.js */ "./src/common/config/html.js");
/* eslint-disable func-names */




const byAlt = function (element) {
  let css = null;
  if (_element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].isImageTag(element)) {
    css = `${_css_selector_js__WEBPACK_IMPORTED_MODULE_1__["default"].getTag(element)}${_css_selector_js__WEBPACK_IMPORTED_MODULE_1__["default"].byAlt(element)}`;
  }
  return css;
};

const bySrc = function (element) {
  let css = null;
  if (_element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].isImageTag(element)) {
    css = `${_css_selector_js__WEBPACK_IMPORTED_MODULE_1__["default"].getTag(element)}${_css_selector_js__WEBPACK_IMPORTED_MODULE_1__["default"].bySrc(element)}`;
  }
  return css;
};

const bySrcAndClass = function (element) {
  let css = null;
  const isHavingSrcAndClass = _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].isHavingAttribute(element, _config_html_js__WEBPACK_IMPORTED_MODULE_2__["default"].ATTRIBUTES.src)
    && _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].isHavingAttribute(element, _config_html_js__WEBPACK_IMPORTED_MODULE_2__["default"].ATTRIBUTES["class"]);

  if (isHavingSrcAndClass) {
    css = `${_css_selector_js__WEBPACK_IMPORTED_MODULE_1__["default"].getTag(element)}`
      + `${_css_selector_js__WEBPACK_IMPORTED_MODULE_1__["default"].bySrc(element)}${_css_selector_js__WEBPACK_IMPORTED_MODULE_1__["default"].byClassName(element)}`;
  }

  return css;
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  byAlt,
  bySrc,
  bySrcAndClass,
});


/***/ }),

/***/ "./src/common/lib/dom-element/css/builder-link.js":
/*!********************************************************!*\
  !*** ./src/common/lib/dom-element/css/builder-link.js ***!
  \********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _config_html_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../config/html.js */ "./src/common/config/html.js");
/* harmony import */ var _element_data_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../element-data.js */ "./src/common/lib/dom-element/element-data.js");
/* harmony import */ var _css_selector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./css-selector.js */ "./src/common/lib/dom-element/css/css-selector.js");
/* eslint-disable func-names */




const byHref = function (element) {
  let css = null;
  if (_element_data_js__WEBPACK_IMPORTED_MODULE_1__["default"].isHavingAttribute(element, _config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.href)) {
    css = `${_css_selector_js__WEBPACK_IMPORTED_MODULE_2__["default"].getTag(element)}${_css_selector_js__WEBPACK_IMPORTED_MODULE_2__["default"].byHref(element)}`;
  }

  return css;
};

const byHrefAndRole = function (element) {
  let css = null;
  const isHavingHrefAndRole = _element_data_js__WEBPACK_IMPORTED_MODULE_1__["default"].isHavingAttribute(element, _config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.href)
    && _element_data_js__WEBPACK_IMPORTED_MODULE_1__["default"].isHavingAttribute(element, _config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.role);

  if (isHavingHrefAndRole) {
    css = `${_css_selector_js__WEBPACK_IMPORTED_MODULE_2__["default"].getTag(element)}`
      + `${_css_selector_js__WEBPACK_IMPORTED_MODULE_2__["default"].byHref(element)}${_css_selector_js__WEBPACK_IMPORTED_MODULE_2__["default"].byRole(element)}`;
  }

  return css;
};

const byHrefAndClass = function (element) {
  let css = null;
  const isHavingHrefAndClass = _element_data_js__WEBPACK_IMPORTED_MODULE_1__["default"].isHavingAttribute(element, _config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.href)
    && _element_data_js__WEBPACK_IMPORTED_MODULE_1__["default"].isHavingAttribute(element, _config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES["class"]);

  if (isHavingHrefAndClass) {
    css = `${_css_selector_js__WEBPACK_IMPORTED_MODULE_2__["default"].getTag(element)}`
      + `${_css_selector_js__WEBPACK_IMPORTED_MODULE_2__["default"].byHref(element)}${_css_selector_js__WEBPACK_IMPORTED_MODULE_2__["default"].byClassName(element)}`;
  }

  return css;
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  byHrefAndRole,
  byHref,
  byHrefAndClass,
});


/***/ }),

/***/ "./src/common/lib/dom-element/css/builder-parent.js":
/*!**********************************************************!*\
  !*** ./src/common/lib/dom-element/css/builder-parent.js ***!
  \**********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _element_data_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../element-data.js */ "./src/common/lib/dom-element/element-data.js");
/* harmony import */ var _css_selector_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./css-selector.js */ "./src/common/lib/dom-element/css/css-selector.js");
/* harmony import */ var _css_finder_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./css-finder.js */ "./src/common/lib/dom-element/css/css-finder.js");
/* eslint-disable func-names */




const byParentAndChildCss = function () {
  let css = null;
  if (this.parentElementCss && this.childElementCss) {
    css = `${this.parentElementCss} > ${this.childElementCss}`;
  }
  return css;
};

const byParentCssAndChildPosition = function () {
  let css = null;
  if (this.parentElement && this.parentElementCss) {
    const childNumber = _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementChildren(this.parentElement)
      .indexOf(this.element) + 1;
    const childTag = _css_selector_js__WEBPACK_IMPORTED_MODULE_1__["default"].getTag(this.element);
    css = `${this.parentElementCss} ${childTag}:nth-child(${childNumber})`;
  }
  return css;
};

const byOffsetParentTag = function () {
  let css = null;
  if (this.parentOffsetCss && this.childElementCss) {
    css = `${this.parentOffsetCss} ${this.childElementCss}`;
  }
  return css;
};

const byGrandParent = function () {
  let css = null;
  const grandParent = _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementParent(this.element);
  if (grandParent) {
    const grandParentCss = _css_finder_js__WEBPACK_IMPORTED_MODULE_2__["default"].getMultiSelector(grandParent);
    if (grandParentCss) {
      css = `${grandParentCss} > ${this.parentElementCss} > ${this.childElementCss}`;
    }
  }
  return css;
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  byOffsetParentTag,
  byParentAndChildCss,
  byParentCssAndChildPosition,
  byGrandParent,
});


/***/ }),

/***/ "./src/common/lib/dom-element/css/builder-sibling.js":
/*!***********************************************************!*\
  !*** ./src/common/lib/dom-element/css/builder-sibling.js ***!
  \***********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _element_data_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../element-data.js */ "./src/common/lib/dom-element/element-data.js");
/* harmony import */ var _css_selector_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./css-selector.js */ "./src/common/lib/dom-element/css/css-selector.js");
/* harmony import */ var _css_finder_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./css-finder.js */ "./src/common/lib/dom-element/css/css-finder.js");
/* eslint-disable func-names */




const byPreviousSibling = function () {
  let css = null;
  const previousSibling = _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementPreviousSibling(this.element);
  if (previousSibling) {
    const previousSiblingCss = _css_finder_js__WEBPACK_IMPORTED_MODULE_2__["default"].getMultiSelector(previousSibling);
    if (previousSiblingCss) {
      css = `${previousSiblingCss} + ${_css_selector_js__WEBPACK_IMPORTED_MODULE_1__["default"].getTag(this.element)}`;
    }
  }
  return css;
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  byPreviousSibling,
});


/***/ }),

/***/ "./src/common/lib/dom-element/css/css-finder-relative.js":
/*!***************************************************************!*\
  !*** ./src/common/lib/dom-element/css/css-finder-relative.js ***!
  \***************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _builder_sibling_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./builder-sibling.js */ "./src/common/lib/dom-element/css/builder-sibling.js");
/* harmony import */ var _builder_parent_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./builder-parent.js */ "./src/common/lib/dom-element/css/builder-parent.js");
/* harmony import */ var _css_selector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./css-selector.js */ "./src/common/lib/dom-element/css/css-selector.js");
/* harmony import */ var _element_data_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../element-data.js */ "./src/common/lib/dom-element/element-data.js");
/* harmony import */ var _css_finder_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./css-finder.js */ "./src/common/lib/dom-element/css/css-finder.js");






const RelativeElementBuilderMap = new Map();

// find css by element relative tags
RelativeElementBuilderMap.set('byPreviousSibling', _builder_sibling_js__WEBPACK_IMPORTED_MODULE_0__["default"].byPreviousSibling);

/* eslint-disable max-len */
RelativeElementBuilderMap.set('byParentAndChildCss', _builder_parent_js__WEBPACK_IMPORTED_MODULE_1__["default"].byParentAndChildCss);
RelativeElementBuilderMap.set('byParentCssAndChildPosition', _builder_parent_js__WEBPACK_IMPORTED_MODULE_1__["default"].byParentCssAndChildPosition);
RelativeElementBuilderMap.set('byOffsetParentTag', _builder_parent_js__WEBPACK_IMPORTED_MODULE_1__["default"].byOffsetParentTag);
RelativeElementBuilderMap.set('byGrandParent', _builder_parent_js__WEBPACK_IMPORTED_MODULE_1__["default"].byGrandParent);
/* eslint-enable max-len */

function getSingleSelector(element) {
  let result = null;
  // relative elements
  this.element = element;
  this.parentElement = _element_data_js__WEBPACK_IMPORTED_MODULE_3__["default"].getElementParent(element);
  this.parentOffsetElement = _element_data_js__WEBPACK_IMPORTED_MODULE_3__["default"].getElementOffsetParent(element);

  // relative possible css which find single or multiple elements
  this.childElementCss = _css_finder_js__WEBPACK_IMPORTED_MODULE_4__["default"].getMultiSelector(element);
  if (this.parentElement) {
    this.parentElementCss = _css_finder_js__WEBPACK_IMPORTED_MODULE_4__["default"].getMultiSelector(this.parentElement);
  }
  if (this.parentOffsetElement) {
    this.parentOffsetCss = _css_finder_js__WEBPACK_IMPORTED_MODULE_4__["default"].getMultiSelector(this.parentOffsetElement);
  }

  // eslint-disable-next-line no-restricted-syntax
  for (const [, value] of RelativeElementBuilderMap) {
    const css = value.call(this);
    if (_css_selector_js__WEBPACK_IMPORTED_MODULE_2__["default"].isFindingElement(css, this.element)) {
      result = css;
      break;
    }
  }
  return result;
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  getSingleSelector,
});


/***/ }),

/***/ "./src/common/lib/dom-element/css/css-finder.js":
/*!******************************************************!*\
  !*** ./src/common/lib/dom-element/css/css-finder.js ***!
  \******************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _builder_attributes_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./builder-attributes.js */ "./src/common/lib/dom-element/css/builder-attributes.js");
/* harmony import */ var _builder_image_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./builder-image.js */ "./src/common/lib/dom-element/css/builder-image.js");
/* harmony import */ var _builder_link_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./builder-link.js */ "./src/common/lib/dom-element/css/builder-link.js");
/* harmony import */ var _css_selector_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./css-selector.js */ "./src/common/lib/dom-element/css/css-selector.js");
/* eslint-disable import/prefer-default-export, func-names */





const ElementBuilderMap = new Map();

// find css for element tag
ElementBuilderMap.set('byId', _builder_attributes_js__WEBPACK_IMPORTED_MODULE_0__["default"].byId);
ElementBuilderMap.set('byName', _builder_attributes_js__WEBPACK_IMPORTED_MODULE_0__["default"].byName);
ElementBuilderMap.set('byDataTestId', _builder_attributes_js__WEBPACK_IMPORTED_MODULE_0__["default"].byDataTestId);
ElementBuilderMap.set('byRole', _builder_attributes_js__WEBPACK_IMPORTED_MODULE_0__["default"].byRole);
ElementBuilderMap.set('byTitle', _builder_attributes_js__WEBPACK_IMPORTED_MODULE_0__["default"].byTitle);
ElementBuilderMap.set('byType', _builder_attributes_js__WEBPACK_IMPORTED_MODULE_0__["default"].byType);
ElementBuilderMap.set('byClass', _builder_attributes_js__WEBPACK_IMPORTED_MODULE_0__["default"].byClass);

ElementBuilderMap.set('byHref', _builder_link_js__WEBPACK_IMPORTED_MODULE_2__["default"].byHref);
ElementBuilderMap.set('byHrefAndRole', _builder_link_js__WEBPACK_IMPORTED_MODULE_2__["default"].byHrefAndRole);
ElementBuilderMap.set('byHrefAndClass', _builder_link_js__WEBPACK_IMPORTED_MODULE_2__["default"].byHrefAndClass);

ElementBuilderMap.set('byAlt', _builder_image_js__WEBPACK_IMPORTED_MODULE_1__["default"].byAlt);
ElementBuilderMap.set('bySrc', _builder_image_js__WEBPACK_IMPORTED_MODULE_1__["default"].bySrc);
ElementBuilderMap.set('bySrcAndClass', _builder_image_js__WEBPACK_IMPORTED_MODULE_1__["default"].bySrcAndClass);

function getSingleSelector(element) {
  let result = null;
  // eslint-disable-next-line no-restricted-syntax
  for (const [, value] of ElementBuilderMap) {
    const css = value.call(this, element);
    if (_css_selector_js__WEBPACK_IMPORTED_MODULE_3__["default"].isFindingElement(css, element)) {
      result = css;
      break;
    }
  }
  return result;
}

/**
 * Identify css which identify single or multi element
 * @param {*} element
 * @returns css selector
 */
function getMultiSelector(element) {
  let result = null;
  // eslint-disable-next-line no-restricted-syntax
  for (const [, value] of ElementBuilderMap) {
    const css = value.call(this, element);
    // eslint-disable-next-line max-len
    const isFindingElement = _css_selector_js__WEBPACK_IMPORTED_MODULE_3__["default"].isFindingMultiElements(css, element) || _css_selector_js__WEBPACK_IMPORTED_MODULE_3__["default"].isFindingElement(css, element);
    if (isFindingElement) {
      result = css;
      break;
    }
  }
  return result;
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  getSingleSelector,
  getMultiSelector,
});


/***/ }),

/***/ "./src/common/lib/dom-element/css/css-selector.js":
/*!********************************************************!*\
  !*** ./src/common/lib/dom-element/css/css-selector.js ***!
  \********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _element_data_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../element-data.js */ "./src/common/lib/dom-element/element-data.js");


function getTag(element) {
  return _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementTagName(element).toLowerCase();
}

function getCombinedClass(element) {
  const className = _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementAttributeClassName(element);
  return className.split(' ').join('.');
}

function isFindingElement(css, element) {
  const elementList = _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementsBySelector(css);
  if (elementList && elementList.length === 1) {
    return elementList[0] === element;
  }
  return false;
}

function isFindingMultiElements(css, element) {
  const elementsList = _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementsBySelector(css);
  if (elementsList && elementsList.length > 1) {
    return Array.from(elementsList).includes(element);
  }
  return false;
}

function byAlt(element) {
  return `[alt='${_element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementAttributeAlt(element)}']`;
}

function byId(element) {
  return `${getTag(element)}#${_element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementAttributeId(element)}`;
}

function byClassName(element) {
  return `.${getCombinedClass(element)}`;
}

function byName(element) {
  return `[name='${_element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementAttributeName(element)}']`;
}

function byDataTestId(element) {
  return `[data-testid='${_element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementAttributeDataTestId(element)}']`;
}

function byTitle(element) {
  return `[title='${_element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementAttributeTitle(element)}']`;
}

function byType(element) {
  return `[type='${_element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementAttributeType(element)}']`;
}

function byRole(element) {
  return `[role='${_element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementAttributeRole(element)}']`;
}

function bySrc(element) {
  return `[src='${_element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementAttributeSrc(element)}']`;
}

function byHref(element) {
  return `[href='${_element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementAttributeHref(element)}']`;
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  byAlt,
  byClassName,
  byDataTestId,
  byId,
  byHref,
  byName,
  byRole,
  bySrc,
  byTitle,
  byType,
  getTag,
  isFindingElement,
  isFindingMultiElements,
});


/***/ }),

/***/ "./src/common/lib/dom-element/element-css.js":
/*!***************************************************!*\
  !*** ./src/common/lib/dom-element/element-css.js ***!
  \***************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _element_data_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./element-data.js */ "./src/common/lib/dom-element/element-data.js");
/* harmony import */ var _css_css_finder_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./css/css-finder.js */ "./src/common/lib/dom-element/css/css-finder.js");
/* harmony import */ var _css_css_finder_relative_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./css/css-finder-relative.js */ "./src/common/lib/dom-element/css/css-finder-relative.js");




function getCssSelector(element) {
  try {
    const cssByElement = _css_css_finder_js__WEBPACK_IMPORTED_MODULE_1__["default"].getSingleSelector(element);
    if (cssByElement) {
      return cssByElement;
    }

    const cssByRelative = _css_css_finder_relative_js__WEBPACK_IMPORTED_MODULE_2__["default"].getSingleSelector(element);
    if (cssByRelative) {
      return cssByRelative;
    }

    return '';
  } catch (e) {
    console.error(e);
    return '';
  }
}

function isMultiElementsCss(css) {
  const elementsList = _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementsBySelector(css);
  if (elementsList) {
    return elementsList.length > 1;
  }
  return false;
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  getCssSelector,
  isMultiElementsCss,
});


/***/ }),

/***/ "./src/common/lib/dom-element/element-data.js":
/*!****************************************************!*\
  !*** ./src/common/lib/dom-element/element-data.js ***!
  \****************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _config_html_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../config/html.js */ "./src/common/config/html.js");


function getElementAttributeAriaLabel(element) {
  return element.getAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.ariaLabel);
}

function getElementAttributeAlt(element) {
  return element.getAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.alt);
}

function getElementAttributeClassName(element) {
  let className = element.getAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES["class"]);
  if (className) {
    className = className.trim()
      .replace('\n', ' ')
      .split(' ')
      .filter((i) => i.length > 0)
      .join(' ');
  }
  return className;
}

function getElementAttributeDataTestId(element) {
  return element.getAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.dataTestId);
}

function getElementAttributeHref(element) {
  return element.getAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.href);
}

function getElementAttributeId(element) {
  return element.getAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.id);
}

function getElementAttributeName(element) {
  return element.getAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.name);
}

function getElementAttributeRole(element) {
  return element.getAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.role);
}

function getElementAttributeSrc(element) {
  return element.getAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.src);
}

function getElementAttributeTitle(element) {
  return element.getAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.title);
}

function getElementAttributeType(element) {
  if (typeof element.getAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.type) === 'string') {
    return element.getAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.type).toLowerCase();
  }
  return element.getAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.type);
}

/**
 * get children node list
 * @param {*} parentElement
 * @returns array of node list
 */
function getElementChildren(parentElement) {
  let children = [];
  if (parentElement.children) {
    children = Array.from(parentElement.children);
  }
  return children;
}

function getElementInnerText(element) {
  let innerText = null;

  if (element.text) {
    innerText = element.text.trim().slice(0, 150);
  } else if (element.textContent) {
    innerText = element.textContent.trim().slice(0, 150);
  } else if (element.innerText) {
    innerText = element.innerText.trim().slice(0, 150);
  }

  return innerText;
}

function getElementInnerValue(element) {
  return element.value;
}

function getElementOffsetParent(element) {
  if (getElementAttributeId(element) !== 'content') {
    return element.offsetParent;
  }
  return null;
}

function getElementParent(element) {
  return element.parentElement;
}

function getElementPreviousSibling(element) {
  return element.previousElementSibling;
}

function getElementSiblingLabelName(element) {
  const previousSibling = getElementPreviousSibling(element);

  if (previousSibling && previousSibling.tagName === _config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.label) {
    return element.previousElementSibling.innerText;
  }
  return false;
}

function getElementTagName(element) {
  if (typeof element.tagName === 'string') {
    return element.tagName.toUpperCase();
  }
  return element.tagName;
}

function isHavingAttribute(element, attribute) {
  return element.hasAttribute(attribute);
}

function isHavingDataTestIdAttribute(element) {
  return element.hasAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.dataTestId);
}

function isHavingIdAttribute(element) {
  return element.hasAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.id);
}

function isHavingNameAttribute(element) {
  return element.hasAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.name);
}

function isHavingTitleAttribute(element) {
  return element.hasAttribute(_config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].ATTRIBUTES.title);
}

function isButtonTag(element) {
  return getElementTagName(element) === _config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.button;
}

function isInputHtmlTag(element) {
  return getElementTagName(element) === _config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.input;
}

function isImageTag(element) {
  return getElementTagName(element) === _config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.img;
}

function isHyperLinkTag(element) {
  return getElementTagName(element) === _config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.a;
}

function isLabelTag(element) {
  return getElementTagName(element) === _config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].TAGS.label;
}

function isRadioInputTag(element) {
  if (isInputHtmlTag(element)) {
    return getElementAttributeType(element) === _config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.radio;
  }
  return false;
}

function isCheckboxInputTag(element) {
  if (isInputHtmlTag(element)) {
    return getElementAttributeType(element) === _config_html_js__WEBPACK_IMPORTED_MODULE_0__["default"].INPUT_TYPE.checkbox;
  }
  return false;
}

function isMultiLocatorName(locatorByName) {
  return document.getElementsByName(locatorByName).length > 1;
}

function getElementsByXpath(xpath) {
  try {
    const result = [];
    const nodeList = document.evaluate(xpath, document, null, XPathResult.ANY_TYPE, null);
    let node = nodeList.iterateNext();
    while (node) {
      result.push(node);
      node = nodeList.iterateNext();
    }
    return result;
  } catch {
    return null;
  }
}

function getElementsBySelector(selector) {
  try {
    return document.querySelectorAll(selector);
  } catch {
    return null;
  }
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  getElementAttributeAlt,
  getElementAttributeAriaLabel,
  getElementAttributeClassName,
  getElementAttributeDataTestId,
  getElementAttributeHref,
  getElementAttributeId,
  getElementAttributeName,
  getElementAttributeRole,
  getElementAttributeSrc,
  getElementAttributeTitle,
  getElementAttributeType,
  getElementChildren,
  getElementInnerText,
  getElementInnerValue,
  getElementOffsetParent,
  getElementParent,
  getElementPreviousSibling,
  getElementSiblingLabelName,
  getElementsBySelector,
  getElementsByXpath,
  getElementTagName,
  isButtonTag,
  isCheckboxInputTag,
  isHavingAttribute,
  isHavingDataTestIdAttribute,
  isHavingIdAttribute,
  isHavingNameAttribute,
  isHavingTitleAttribute,
  isHyperLinkTag,
  isInputHtmlTag,
  isImageTag,
  isLabelTag,
  isMultiLocatorName,
  isRadioInputTag,
});


/***/ }),

/***/ "./src/common/lib/dom-element/element-name.js":
/*!****************************************************!*\
  !*** ./src/common/lib/dom-element/element-name.js ***!
  \****************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _element_data_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./element-data.js */ "./src/common/lib/dom-element/element-data.js");
/* eslint-disable func-names */


const NameBuilderMap = new Map();

function getAttributeName(element) {
  return _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementAttributeName(element);
}

function getAttributeTitle(element) {
  return _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementAttributeTitle(element);
}

function getLabelName(element) {
  return _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementSiblingLabelName(element);
}

function getInnerText(element) {
  return _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementInnerText(element);
}

function getInnerValue(element) {
  return _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementInnerValue(element);
}

const byName = function (element) {
  let name = null;
  if (_element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].isHavingNameAttribute(element)) {
    name = getAttributeName(element);
  }
  return name;
};

const byTitle = function (element) {
  let name = null;
  if (_element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].isHavingTitleAttribute(element)) {
    name = getAttributeTitle(element);
  }
  return name;
};

const bySiblingLabel = function (element) {
  let name = null;
  if (_element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementSiblingLabelName(element)) {
    name = getLabelName(element);
  }
  return name;
};

const byInnerText = function (element) {
  let name = null;
  if (_element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementInnerText(element)) {
    name = getInnerText(element);
  }
  return name;
};

const byValue = function (element) {
  let name = null;
  if (_element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementInnerValue(element)) {
    name = getInnerValue(element);
  }
  return name;
};

const byAlternateText = function (element) {
  let name = null;
  if (_element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementAttributeAlt(element)) {
    name = _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementAttributeAlt(element);
  }
  return name;
};

// find name for element tag
NameBuilderMap.set('byName', byName);
NameBuilderMap.set('byTitle', byTitle);
NameBuilderMap.set('bySiblingLabel', bySiblingLabel);
NameBuilderMap.set('byInnerText', byInnerText);
NameBuilderMap.set('byValue', byValue);
NameBuilderMap.set('byAlternateText', byAlternateText);

function getRelativeName(element) {
  let result = '';
  // eslint-disable-next-line no-restricted-syntax
  for (const [, value] of NameBuilderMap) {
    const name = value.call(this, element);
    if (name) {
      result = name.slice(0, 60);
      break;
    }
  }
  return result;
}

function getNameAttribute(element) {
  return getAttributeName(element) || '';
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  getNameAttribute,
  getRelativeName,
});


/***/ }),

/***/ "./src/common/lib/dom-element/element-notify.js":
/*!******************************************************!*\
  !*** ./src/common/lib/dom-element/element-notify.js ***!
  \******************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _config_locators_config_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../config/locators-config.js */ "./src/common/config/locators-config.js");
/* harmony import */ var _element_data_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./element-data.js */ "./src/common/lib/dom-element/element-data.js");



const { LOCATOR_TYPE } = _config_locators_config_js__WEBPACK_IMPORTED_MODULE_0__["default"];

const FLASH_ELEMENT_IN_SECONDS = 2;

const NOTIFY_RESPONSE = {
  singleElement: 'singleElement',
  invalid: 'invalid',
  multiElement: 'multiElement',
};

function getElementList(locatorType, locatorValue) {
  let elementList = [];
  switch (locatorType) {
  case LOCATOR_TYPE.css:
    elementList = _element_data_js__WEBPACK_IMPORTED_MODULE_1__["default"].getElementsBySelector(locatorValue);
    break;
  case LOCATOR_TYPE.id:
    if (document.getElementById(locatorValue)) {
      elementList.push(document.getElementById(locatorValue));
    }
    break;
  case LOCATOR_TYPE.name:
    elementList = document.getElementsByName(locatorValue);
    break;
  default:
    elementList = _element_data_js__WEBPACK_IMPORTED_MODULE_1__["default"].getElementsByXpath(locatorValue);
    break;
  }
  return elementList;
}

function wait(seconds) {
  return new Promise((resolve) => setTimeout(resolve, seconds * 1000));
}

function flashElement(element, timeOut) {
  // extract style
  const { borderColor, borderStyle, borderWidth } = element.style;
  element.style.borderColor = 'red';
  element.style.borderStyle = 'dashed';
  element.style.borderWidth = 'medium';
  wait(timeOut).then(() => {
    // reset the style
    element.style.borderColor = borderColor || '';
    element.style.borderStyle = borderStyle || '';
    element.style.borderWidth = borderWidth || '';
  });
}

function notifyElement(element) {
  element.focus();
  flashElement(element, FLASH_ELEMENT_IN_SECONDS);
}

function notify(locatorType, locatorValue) {
  try {
    let result;
    const elementList = getElementList(locatorType, locatorValue);
    if (elementList && elementList.length === 1) {
      notifyElement(elementList[0]);
      result = NOTIFY_RESPONSE.singleElement;
    } else if (elementList.length > 1) {
      result = NOTIFY_RESPONSE.multiElement;
    } else {
      result = NOTIFY_RESPONSE.invalid;
    }
    return result;
  } catch (e) {
    console.error(e);
    return NOTIFY_RESPONSE.invalid;
  }
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  notify,
  NOTIFY_RESPONSE,
});


/***/ }),

/***/ "./src/common/lib/dom-element/element-type.js":
/*!****************************************************!*\
  !*** ./src/common/lib/dom-element/element-type.js ***!
  \****************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _element_data_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./element-data.js */ "./src/common/lib/dom-element/element-data.js");
/* harmony import */ var _config_element_type_config_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../config/element-type-config.js */ "./src/common/config/element-type-config.js");
/* harmony import */ var _config_html_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../config/html.js */ "./src/common/config/html.js");
/* eslint-disable func-names */




const typeBuilderMap = new Map();

function getTagName(element) {
  return _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementTagName(element);
}

const byTagMapping = function (element) {
  let elementType = null;
  const mappedValue = _config_element_type_config_js__WEBPACK_IMPORTED_MODULE_1__["default"].ELEMENT_TAGNAME_MAPPING[getTagName(element)];
  if (mappedValue !== undefined) {
    elementType = mappedValue;
  }
  return elementType;
};

const byRole = function (element) {
  let elementType = null;
  const role = _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementAttributeRole(element);
  const mappedValue = _config_element_type_config_js__WEBPACK_IMPORTED_MODULE_1__["default"].VALID_ELEMENT_TYPE[role];
  if (mappedValue !== undefined) {
    elementType = mappedValue;
  }
  return elementType;
};

const byInputType = function (element) {
  let elementType = null;
  if (_element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].isInputHtmlTag(element)) {
    const type = _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementAttributeType(element);
    const mappedValue = _config_element_type_config_js__WEBPACK_IMPORTED_MODULE_1__["default"].ELEMENT_INPUT_TYPE_MAPPING[type];
    if (mappedValue !== undefined) {
      elementType = mappedValue;
    }
  }
  return elementType;
};

const byLink = function (element) {
  let elementType = null;
  if (_element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].isHyperLinkTag(element)) {
    elementType = _config_element_type_config_js__WEBPACK_IMPORTED_MODULE_1__["default"].VALID_ELEMENT_TYPE.link;
  }
  return elementType;
};

const byParentRole = function (element) {
  let elementType = null;
  const parentElement = _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementOffsetParent(element);
  if (parentElement) {
    elementType = byRole(parentElement);
  }
  return elementType;
};

const byContainerTagAssociatedToParent = function (element) {
  let elementType = null;
  if (_config_html_js__WEBPACK_IMPORTED_MODULE_2__["default"].CONTAINER_TAGS.includes(getTagName(element))) {
    const parentElement = _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementOffsetParent(element);
    if (parentElement) {
      elementType = byTagMapping(parentElement);
    }
  }
  return elementType;
};

const byParentTagMapping = function (element) {
  let elementType = null;
  const parentElement = _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementParent(element);

  if (parentElement) {
    elementType = byTagMapping(parentElement);
  }
  return elementType;
};

const byAssociatedInputTag = function (element) {
  let elementType = null;
  const previousSibling = _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementPreviousSibling(element);
  if (previousSibling) {
    elementType = byInputType(previousSibling);
  }
  return elementType;
};

const byParent = function (element) {
  let elementType = null;
  const parentElement = _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementParent(element);
  if (byRole(parentElement)) {
    elementType = byRole(parentElement);
  } else if (byLink(parentElement)) {
    elementType = byLink(parentElement);
  }
  return elementType;
};

// to find type in below order
typeBuilderMap.set('byRole', byRole);
typeBuilderMap.set('byTagMapping', byTagMapping);
typeBuilderMap.set('byInputType', byInputType);
typeBuilderMap.set('byLink', byLink);
typeBuilderMap.set('byParentRole', byParentRole);
typeBuilderMap.set('byContainerTagAssociatedToParent', byContainerTagAssociatedToParent);
typeBuilderMap.set('byParentTagMapping', byParentTagMapping);
typeBuilderMap.set('byAssociatedInputTag', byAssociatedInputTag);
typeBuilderMap.set('byParent', byParent);

function getElementType(element) {
  let result = '';
  try {
    // eslint-disable-next-line no-restricted-syntax
    for (const [, value] of typeBuilderMap) {
      const elementType = value.call(this, element);
      if (elementType) {
        result = elementType;
        break;
      }
    }
  } catch (e) {
    console.error(e);
    result = '';
  }
  return result;
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  getElementType,
});


/***/ }),

/***/ "./src/common/lib/dom-element/element-xpath.js":
/*!*****************************************************!*\
  !*** ./src/common/lib/dom-element/element-xpath.js ***!
  \*****************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _element_data_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./element-data.js */ "./src/common/lib/dom-element/element-data.js");
/* harmony import */ var _xpath_xpath_finder_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./xpath/xpath-finder.js */ "./src/common/lib/dom-element/xpath/xpath-finder.js");
/* harmony import */ var _xpath_xpath_finder_relative_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./xpath/xpath-finder-relative.js */ "./src/common/lib/dom-element/xpath/xpath-finder-relative.js");




function getXpathSelector(element) {
  try {
    const xpathByElement = _xpath_xpath_finder_js__WEBPACK_IMPORTED_MODULE_1__["default"].getSingleSelector(element);
    if (xpathByElement) {
      return xpathByElement;
    }

    const xpathByRelative = _xpath_xpath_finder_relative_js__WEBPACK_IMPORTED_MODULE_2__["default"].getSingleSelector(element);
    if (xpathByRelative) {
      return xpathByRelative;
    }

    return '';
  } catch (e) {
    console.error(e);
    return '';
  }
}

function isMultiElementsXpath(xpath) {
  const elementsList = _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementsByXpath(xpath);
  if (elementsList) {
    return elementsList.length > 1;
  }
  return false;
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  getXpathSelector,
  isMultiElementsXpath,
});


/***/ }),

/***/ "./src/common/lib/dom-element/xpath/builder-attributes.js":
/*!****************************************************************!*\
  !*** ./src/common/lib/dom-element/xpath/builder-attributes.js ***!
  \****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _xpath_selector_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./xpath-selector.js */ "./src/common/lib/dom-element/xpath/xpath-selector.js");
/* harmony import */ var _element_data_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../element-data.js */ "./src/common/lib/dom-element/element-data.js");
/* harmony import */ var _config_html_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../config/html.js */ "./src/common/config/html.js");
/* eslint-disable func-names */




const byId = function (element) {
  let xpath = null;
  if (_element_data_js__WEBPACK_IMPORTED_MODULE_1__["default"].isHavingIdAttribute(element)) {
    xpath = _xpath_selector_js__WEBPACK_IMPORTED_MODULE_0__["default"].byId(element);
  }
  return xpath;
};

const byName = function (element) {
  let xpath = null;
  if (_element_data_js__WEBPACK_IMPORTED_MODULE_1__["default"].isHavingNameAttribute(element)) {
    xpath = _xpath_selector_js__WEBPACK_IMPORTED_MODULE_0__["default"].byName(element);
  }
  return xpath;
};

const byTitle = function (element) {
  let xpath = null;
  if (_element_data_js__WEBPACK_IMPORTED_MODULE_1__["default"].isHavingTitleAttribute(element)) {
    xpath = _xpath_selector_js__WEBPACK_IMPORTED_MODULE_0__["default"].byTitle(element);
  }
  return xpath;
};

const byDataTestId = function (element) {
  let xpath = null;
  if (_element_data_js__WEBPACK_IMPORTED_MODULE_1__["default"].isHavingDataTestIdAttribute(element)) {
    xpath = _xpath_selector_js__WEBPACK_IMPORTED_MODULE_0__["default"].byDataTestId(element);
  }
  return xpath;
};

const byAriaLabel = function (element) {
  let xpath = null;
  if (_element_data_js__WEBPACK_IMPORTED_MODULE_1__["default"].isHavingAttribute(element, _config_html_js__WEBPACK_IMPORTED_MODULE_2__["default"].ATTRIBUTES.ariaLabel)) {
    xpath = _xpath_selector_js__WEBPACK_IMPORTED_MODULE_0__["default"].byAriaLabel(element);
  }
  return xpath;
};

const byClass = function (element) {
  let xpath = null;
  const className = _element_data_js__WEBPACK_IMPORTED_MODULE_1__["default"].getElementAttributeClassName(element);
  if (className) {
    xpath = _xpath_selector_js__WEBPACK_IMPORTED_MODULE_0__["default"].byClass(element);
  }
  return xpath;
};

const byType = function (element) {
  let xpath;
  const isHavingTypeAttribute = _element_data_js__WEBPACK_IMPORTED_MODULE_1__["default"].isHavingAttribute(element, _config_html_js__WEBPACK_IMPORTED_MODULE_2__["default"].ATTRIBUTES.type);
  if (isHavingTypeAttribute) {
    xpath = _xpath_selector_js__WEBPACK_IMPORTED_MODULE_0__["default"].byTypeAttribute(element);
  }
  return xpath;
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  byAriaLabel,
  byClass,
  byDataTestId,
  byId,
  byName,
  byTitle,
  byType,
});


/***/ }),

/***/ "./src/common/lib/dom-element/xpath/builder-image.js":
/*!***********************************************************!*\
  !*** ./src/common/lib/dom-element/xpath/builder-image.js ***!
  \***********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _xpath_selector_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./xpath-selector.js */ "./src/common/lib/dom-element/xpath/xpath-selector.js");
/* harmony import */ var _element_data_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../element-data.js */ "./src/common/lib/dom-element/element-data.js");
/* harmony import */ var _config_html_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../config/html.js */ "./src/common/config/html.js");
/* eslint-disable func-names */




const byImageAlt = function (element) {
  let xpath = null;
  if (_element_data_js__WEBPACK_IMPORTED_MODULE_1__["default"].isImageTag(element)
    && _element_data_js__WEBPACK_IMPORTED_MODULE_1__["default"].isHavingAttribute(element, _config_html_js__WEBPACK_IMPORTED_MODULE_2__["default"].ATTRIBUTES.alt)) {
    xpath = _xpath_selector_js__WEBPACK_IMPORTED_MODULE_0__["default"].byAltAttribute(element);
  }
  return xpath;
};

const byImageSrc = function (element) {
  let xpath = null;
  if (_element_data_js__WEBPACK_IMPORTED_MODULE_1__["default"].isImageTag(element)
    && _element_data_js__WEBPACK_IMPORTED_MODULE_1__["default"].isHavingAttribute(element, _config_html_js__WEBPACK_IMPORTED_MODULE_2__["default"].ATTRIBUTES.src)) {
    xpath = _xpath_selector_js__WEBPACK_IMPORTED_MODULE_0__["default"].bySrcAttribute(element);
  }
  return xpath;
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  byImageAlt,
  byImageSrc,
});


/***/ }),

/***/ "./src/common/lib/dom-element/xpath/builder-link.js":
/*!**********************************************************!*\
  !*** ./src/common/lib/dom-element/xpath/builder-link.js ***!
  \**********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _xpath_selector_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./xpath-selector.js */ "./src/common/lib/dom-element/xpath/xpath-selector.js");
/* harmony import */ var _element_data_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../element-data.js */ "./src/common/lib/dom-element/element-data.js");
/* harmony import */ var _config_html_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../config/html.js */ "./src/common/config/html.js");
/* eslint-disable func-names */




const byLinkHref = function (element) {
  let xpath = null;
  const href = _element_data_js__WEBPACK_IMPORTED_MODULE_1__["default"].getElementAttributeHref(element);
  if (href) {
    xpath = _xpath_selector_js__WEBPACK_IMPORTED_MODULE_0__["default"].byAttribute(
      _element_data_js__WEBPACK_IMPORTED_MODULE_1__["default"].getElementTagName(element),
      _config_html_js__WEBPACK_IMPORTED_MODULE_2__["default"].ATTRIBUTES.href,
      href,
    );
  }
  return xpath;
};

const byLinkHrefAndClass = function (element) {
  let xpath = null;
  const href = _element_data_js__WEBPACK_IMPORTED_MODULE_1__["default"].getElementAttributeHref(element);
  const className = _element_data_js__WEBPACK_IMPORTED_MODULE_1__["default"].getElementAttributeClassName(element);
  if (className && href) {
    xpath = byLinkHref(element);
    xpath = `${xpath}${_xpath_selector_js__WEBPACK_IMPORTED_MODULE_0__["default"].getClassTag(className)}`;
  }
  return xpath;
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  byLinkHref,
  byLinkHrefAndClass,
});


/***/ }),

/***/ "./src/common/lib/dom-element/xpath/builder-parent.js":
/*!************************************************************!*\
  !*** ./src/common/lib/dom-element/xpath/builder-parent.js ***!
  \************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _element_data_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../element-data.js */ "./src/common/lib/dom-element/element-data.js");
/* harmony import */ var _xpath_finder_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./xpath-finder.js */ "./src/common/lib/dom-element/xpath/xpath-finder.js");
/* eslint-disable func-names */



const byParentAndChildXpath = function () {
  let xpath = null;
  if (this.parentElementXpath && this.childElementXpath) {
    xpath = `${this.parentElementXpath}/${this.childElementXpath.slice(2)}`; // slice to elimnate \\
  }
  return xpath;
};

const byParentXpathAndChildPosition = function () {
  let xpath = null;
  if (this.parentElementXpath) {
    const childNumber = _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementChildren(this.parentElement)
      .filter((node) => node.tagName === _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementTagName(this.element))
      .indexOf(this.element) + 1;
    const childTag = _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementTagName(this.element).toLowerCase();
    xpath = `${this.parentElementXpath}/${childTag}[${childNumber}]`;
  }
  return xpath;
};

const byOffsetParent = function () {
  let xpath = null;
  if (this.parentOffsetXpath && this.childElementXpath) {
    xpath = `${this.parentOffsetXpath}//${this.childElementXpath.slice(2)}`; // slice to remove \\
  }
  return xpath;
};

const byGrandParent = function () {
  let xpath = null;
  const grandParent = _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementParent(this.parentElement);

  if (this.parentElement && grandParent) {
    const grandParentXpath = _xpath_finder_js__WEBPACK_IMPORTED_MODULE_1__["default"].getMultiSelector(grandParent);
    if (grandParentXpath && this.parentElementXpath && this.childElementXpath) {
      xpath = `${grandParentXpath}`
      + `/${this.parentElementXpath.slice(2)}/${this.childElementXpath.slice(2)}`;
      // slice to elimnate \\
    }
  }
  return xpath;
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  byOffsetParent,
  byParentAndChildXpath,
  byParentXpathAndChildPosition,
  byGrandParent,
});


/***/ }),

/***/ "./src/common/lib/dom-element/xpath/builder-sibling.js":
/*!*************************************************************!*\
  !*** ./src/common/lib/dom-element/xpath/builder-sibling.js ***!
  \*************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _element_data_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../element-data.js */ "./src/common/lib/dom-element/element-data.js");
/* harmony import */ var _xpath_finder_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./xpath-finder.js */ "./src/common/lib/dom-element/xpath/xpath-finder.js");
/* eslint-disable func-names */



const byPreviousSibling = function () {
  let xpath = null;
  const previousSibling = _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementPreviousSibling(this.element);
  const tagName = _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementTagName(this.element).toLowerCase();

  if (previousSibling) {
    const previousSiblingXpath = _xpath_finder_js__WEBPACK_IMPORTED_MODULE_1__["default"].getMultiSelector(previousSibling);
    if (previousSiblingXpath) {
      xpath = `${previousSiblingXpath}/following::${tagName}[1]`;
    }
  }
  return xpath;
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  byPreviousSibling,
});


/***/ }),

/***/ "./src/common/lib/dom-element/xpath/builder-text.js":
/*!**********************************************************!*\
  !*** ./src/common/lib/dom-element/xpath/builder-text.js ***!
  \**********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _xpath_selector_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./xpath-selector.js */ "./src/common/lib/dom-element/xpath/xpath-selector.js");
/* harmony import */ var _element_data_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../element-data.js */ "./src/common/lib/dom-element/element-data.js");
/* harmony import */ var _config_html_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../config/html.js */ "./src/common/config/html.js");
/* eslint-disable func-names */




const byText = function (element) {
  return _xpath_selector_js__WEBPACK_IMPORTED_MODULE_0__["default"].byInnerText(element);
};

const byContainsText = function (element) {
  return _xpath_selector_js__WEBPACK_IMPORTED_MODULE_0__["default"].byContainsText(element);
};

const byRoleAndText = function (element) {
  let xpath = null;
  const role = _element_data_js__WEBPACK_IMPORTED_MODULE_1__["default"].getElementAttributeRole(element);
  if (role) {
    xpath = _xpath_selector_js__WEBPACK_IMPORTED_MODULE_0__["default"].byInnerText(element);
    xpath = `${xpath}${_xpath_selector_js__WEBPACK_IMPORTED_MODULE_0__["default"].getRoleTag(role)}`;
  }
  return xpath;
};

const byRoleAndContainsText = function (element) {
  let xpath = null;
  const role = _element_data_js__WEBPACK_IMPORTED_MODULE_1__["default"].getElementAttributeRole(element);
  if (role) {
    xpath = _xpath_selector_js__WEBPACK_IMPORTED_MODULE_0__["default"].byContainsText(element);
    xpath = `${xpath}${_xpath_selector_js__WEBPACK_IMPORTED_MODULE_0__["default"].getRoleTag(role)}`;
  }
  return xpath;
};

const byHeaderContainsText = function (element) {
  let xpath = null;
  const isHeaderTag = _config_html_js__WEBPACK_IMPORTED_MODULE_2__["default"].HEADER_TAGS.includes(_element_data_js__WEBPACK_IMPORTED_MODULE_1__["default"].getElementTagName(element));
  if (isHeaderTag) {
    xpath = _xpath_selector_js__WEBPACK_IMPORTED_MODULE_0__["default"].byContainsText(element);
  }
  return xpath;
};

const byTextAndClass = function (element) {
  let xpath = null;
  const className = _element_data_js__WEBPACK_IMPORTED_MODULE_1__["default"].getElementAttributeClassName(element);
  if (className) {
    xpath = _xpath_selector_js__WEBPACK_IMPORTED_MODULE_0__["default"].byInnerText(element);
    xpath = `${xpath}${_xpath_selector_js__WEBPACK_IMPORTED_MODULE_0__["default"].getClassTag(className)}`;
  }
  return xpath;
};

const byContainsTextAndClass = function (element) {
  let xpath = null;
  const className = _element_data_js__WEBPACK_IMPORTED_MODULE_1__["default"].getElementAttributeClassName(element);
  if (className) {
    xpath = _xpath_selector_js__WEBPACK_IMPORTED_MODULE_0__["default"].byContainsText(element);
    xpath = `${xpath}${_xpath_selector_js__WEBPACK_IMPORTED_MODULE_0__["default"].getClassTag(className)}`;
  }
  return xpath;
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  byHeaderContainsText,
  byRoleAndContainsText,
  byRoleAndText,
  byText,
  byContainsText,
  byTextAndClass,
  byContainsTextAndClass,
});


/***/ }),

/***/ "./src/common/lib/dom-element/xpath/xpath-finder-relative.js":
/*!*******************************************************************!*\
  !*** ./src/common/lib/dom-element/xpath/xpath-finder-relative.js ***!
  \*******************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _builder_sibling_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./builder-sibling.js */ "./src/common/lib/dom-element/xpath/builder-sibling.js");
/* harmony import */ var _builder_parent_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./builder-parent.js */ "./src/common/lib/dom-element/xpath/builder-parent.js");
/* harmony import */ var _xpath_selector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./xpath-selector.js */ "./src/common/lib/dom-element/xpath/xpath-selector.js");
/* harmony import */ var _element_data_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../element-data.js */ "./src/common/lib/dom-element/element-data.js");
/* harmony import */ var _xpath_finder_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./xpath-finder.js */ "./src/common/lib/dom-element/xpath/xpath-finder.js");






const RelativeElementBuilderMap = new Map();

// find xpath by element relative tags
RelativeElementBuilderMap.set('byPreviousSibling', _builder_sibling_js__WEBPACK_IMPORTED_MODULE_0__["default"].byPreviousSibling);

/* eslint-disable max-len */
RelativeElementBuilderMap.set('byParentAndChildXpath', _builder_parent_js__WEBPACK_IMPORTED_MODULE_1__["default"].byParentAndChildXpath);
RelativeElementBuilderMap.set('byParentXpathAndChildPosition', _builder_parent_js__WEBPACK_IMPORTED_MODULE_1__["default"].byParentXpathAndChildPosition);
RelativeElementBuilderMap.set('byOffsetParent', _builder_parent_js__WEBPACK_IMPORTED_MODULE_1__["default"].byOffsetParent);
RelativeElementBuilderMap.set('byGrandParent', _builder_parent_js__WEBPACK_IMPORTED_MODULE_1__["default"].byGrandParent);
/* eslint-enable max-len */

function getSingleSelector(element) {
  let result = null;

  // relative tags
  this.element = element;
  this.parentElement = _element_data_js__WEBPACK_IMPORTED_MODULE_3__["default"].getElementParent(element);
  this.parentOffsetElement = _element_data_js__WEBPACK_IMPORTED_MODULE_3__["default"].getElementOffsetParent(element);
  this.childElementXpath = null;
  this.parentElementXpath = null;
  this.parentOffsetXpath = null;

  this.childElementXpath = _xpath_finder_js__WEBPACK_IMPORTED_MODULE_4__["default"].getMultiSelector(element);
  if (this.parentElement) {
    this.parentElementXpath = _xpath_finder_js__WEBPACK_IMPORTED_MODULE_4__["default"].getMultiSelector(this.parentElement);
  }
  if (this.parentOffsetElement) {
    this.parentOffsetXpath = _xpath_finder_js__WEBPACK_IMPORTED_MODULE_4__["default"].getMultiSelector(this.parentOffsetElement);
  }

  // eslint-disable-next-line no-restricted-syntax
  for (const [, value] of RelativeElementBuilderMap) {
    const xpath = value.call(this);
    if (_xpath_selector_js__WEBPACK_IMPORTED_MODULE_2__["default"].isFindingElement(xpath, element)) {
      result = xpath;
      break;
    }
  }
  return result;
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  getSingleSelector,
});


/***/ }),

/***/ "./src/common/lib/dom-element/xpath/xpath-finder.js":
/*!**********************************************************!*\
  !*** ./src/common/lib/dom-element/xpath/xpath-finder.js ***!
  \**********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _builder_attributes_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./builder-attributes.js */ "./src/common/lib/dom-element/xpath/builder-attributes.js");
/* harmony import */ var _xpath_selector_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./xpath-selector.js */ "./src/common/lib/dom-element/xpath/xpath-selector.js");
/* harmony import */ var _builder_link_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./builder-link.js */ "./src/common/lib/dom-element/xpath/builder-link.js");
/* harmony import */ var _builder_text_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./builder-text.js */ "./src/common/lib/dom-element/xpath/builder-text.js");
/* harmony import */ var _builder_image_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./builder-image.js */ "./src/common/lib/dom-element/xpath/builder-image.js");






const ElementBuilderMap = new Map();

const keys = {
  byId: 'byId',
  byName: 'byName',
  byDataTestId: 'byDataTestId',
  byTitle: 'byTitle',
  byLinkHref: 'byLinkHref',
  byLinkHrefAndClass: 'byLinkHrefAndClass',
  byImageAlt: 'byImageAlt',
  byImageSrc: 'byImageSrc',
  byHeaderContainsText: 'byHeaderContainsText',
  byType: 'byType',
  byClass: 'byClass',
  byRoleAndText: 'byRoleAndText',
  byRoleAndContainsText: 'byRoleAndContainsText',
  byText: 'byText',
  byContainsText: 'byContainsText',
  byTextAndClass: 'byTextAndClass',
  byContainsTextAndClass: 'byContainsTextAndClass',
  byAriaLabel: 'byAriaLabel',
};

// find xpath for element in below order
ElementBuilderMap.set(keys.byId, _builder_attributes_js__WEBPACK_IMPORTED_MODULE_0__["default"].byId);
ElementBuilderMap.set(keys.byName, _builder_attributes_js__WEBPACK_IMPORTED_MODULE_0__["default"].byName);
ElementBuilderMap.set(keys.byDataTestId, _builder_attributes_js__WEBPACK_IMPORTED_MODULE_0__["default"].byDataTestId);
ElementBuilderMap.set(keys.byTitle, _builder_attributes_js__WEBPACK_IMPORTED_MODULE_0__["default"].byTitle);
ElementBuilderMap.set(keys.byLinkHref, _builder_link_js__WEBPACK_IMPORTED_MODULE_2__["default"].byLinkHref);
ElementBuilderMap.set(keys.byLinkHrefAndClass, _builder_link_js__WEBPACK_IMPORTED_MODULE_2__["default"].byLinkHrefAndClass);
ElementBuilderMap.set(keys.byImageAlt, _builder_image_js__WEBPACK_IMPORTED_MODULE_4__["default"].byImageAlt);
ElementBuilderMap.set(keys.byImageSrc, _builder_image_js__WEBPACK_IMPORTED_MODULE_4__["default"].byImageSrc);
ElementBuilderMap.set(keys.byHeaderContainsText, _builder_text_js__WEBPACK_IMPORTED_MODULE_3__["default"].byHeaderContainsText);
ElementBuilderMap.set(keys.byType, _builder_attributes_js__WEBPACK_IMPORTED_MODULE_0__["default"].byType);
ElementBuilderMap.set(keys.byClass, _builder_attributes_js__WEBPACK_IMPORTED_MODULE_0__["default"].byClass);
ElementBuilderMap.set(keys.byRoleAndText, _builder_text_js__WEBPACK_IMPORTED_MODULE_3__["default"].byRoleAndText);
ElementBuilderMap.set(keys.byRoleAndContainsText, _builder_text_js__WEBPACK_IMPORTED_MODULE_3__["default"].byRoleAndContainsText);
ElementBuilderMap.set(keys.byText, _builder_text_js__WEBPACK_IMPORTED_MODULE_3__["default"].byText);
ElementBuilderMap.set(keys.byContainsText, _builder_text_js__WEBPACK_IMPORTED_MODULE_3__["default"].byContainsText);
ElementBuilderMap.set(keys.byTextAndClass, _builder_text_js__WEBPACK_IMPORTED_MODULE_3__["default"].byTextAndClass);
ElementBuilderMap.set(keys.byContainsTextAndClass, _builder_text_js__WEBPACK_IMPORTED_MODULE_3__["default"].byContainsTextAndClass);
ElementBuilderMap.set(keys.byAriaLabel, _builder_attributes_js__WEBPACK_IMPORTED_MODULE_0__["default"].byAriaLabel);

function getSingleSelector(element) {
  let result = null;
  // eslint-disable-next-line no-restricted-syntax
  for (const [, value] of ElementBuilderMap) {
    const xpath = value.call(this, element);
    if (_xpath_selector_js__WEBPACK_IMPORTED_MODULE_1__["default"].isFindingElement(xpath, element)) {
      result = xpath;
      break;
    }
  }
  return result;
}

/**
 * Identify xpath which identify single or multi element
 * @param {*} element
 * @returns xpath selector first preference to single
 */
function getMultiSelector(element) {
  let result = null;

  if (getSingleSelector(element)) {
    result = getSingleSelector(element);
  } else {
    // eslint-disable-next-line no-restricted-syntax
    for (const [, value] of ElementBuilderMap) {
      const xpath = value.call(this, element);
      const isFindingElement = _xpath_selector_js__WEBPACK_IMPORTED_MODULE_1__["default"].isFindingMultiElements(xpath, element);
      if (isFindingElement) {
        result = xpath;
        break;
      }
    }
  }
  return result;
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  getSingleSelector,
  getMultiSelector,
  ElementBuilderMap, // for unit test
  keys, // for unit tests
});


/***/ }),

/***/ "./src/common/lib/dom-element/xpath/xpath-selector.js":
/*!************************************************************!*\
  !*** ./src/common/lib/dom-element/xpath/xpath-selector.js ***!
  \************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _element_data_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../element-data.js */ "./src/common/lib/dom-element/element-data.js");
/* harmony import */ var _config_html_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../config/html.js */ "./src/common/config/html.js");



function getRoleTag(role) {
  return `[@role='${role}']`;
}

function getClassTag(className) {
  return `[normalize-space(@class)='${className}']`;
}

function byAttribute(baseTag, attribute, value) {
  if (attribute === _config_html_js__WEBPACK_IMPORTED_MODULE_1__["default"].ATTRIBUTES.id) {
    return `//${baseTag.toLowerCase()}[@${attribute}='${value.trim()}']`;
  }
  return `//${baseTag.toLowerCase()}[normalize-space(@${attribute})='${value.trim()}']`;
}

function isFindingElement(xpath, element) {
  const elementsList = _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementsByXpath(xpath);
  if (elementsList && elementsList.length === 1) {
    return elementsList[0] === element;
  }
  return false;
}

function isFindingMultiElements(xpath, element) {
  const elementsList = _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementsByXpath(xpath);
  if (elementsList && elementsList.length > 1) {
    return elementsList.includes(element);
  }
  return false;
}

function byClass(element) {
  return byAttribute(
    _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementTagName(element),
    _config_html_js__WEBPACK_IMPORTED_MODULE_1__["default"].ATTRIBUTES["class"],
    _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementAttributeClassName(element),
  );
}

function byAriaLabel(element) {
  return byAttribute(
    _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementTagName(element),
    _config_html_js__WEBPACK_IMPORTED_MODULE_1__["default"].ATTRIBUTES.ariaLabel,
    _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementAttributeAriaLabel(element),
  );
}

function byAltAttribute(element) {
  return byAttribute(
    _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementTagName(element),
    _config_html_js__WEBPACK_IMPORTED_MODULE_1__["default"].ATTRIBUTES.alt,
    _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementAttributeAlt(element),
  );
}

function bySrcAttribute(element) {
  return byAttribute(
    _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementTagName(element),
    _config_html_js__WEBPACK_IMPORTED_MODULE_1__["default"].ATTRIBUTES.src,
    _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementAttributeSrc(element),
  );
}

function byDataTestId(element) {
  return byAttribute(
    _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementTagName(element),
    _config_html_js__WEBPACK_IMPORTED_MODULE_1__["default"].ATTRIBUTES.dataTestId,
    _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementAttributeDataTestId(element),
  );
}

function byId(element) {
  return byAttribute(
    _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementTagName(element),
    _config_html_js__WEBPACK_IMPORTED_MODULE_1__["default"].ATTRIBUTES.id,
    _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementAttributeId(element),
  );
}

function byName(element) {
  return byAttribute(
    _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementTagName(element),
    _config_html_js__WEBPACK_IMPORTED_MODULE_1__["default"].ATTRIBUTES.name,
    _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementAttributeName(element),
  );
}

function byTitle(element) {
  return byAttribute(
    _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementTagName(element),
    _config_html_js__WEBPACK_IMPORTED_MODULE_1__["default"].ATTRIBUTES.title,
    _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementAttributeTitle(element),
  );
}

function byTypeAttribute(element) {
  return byAttribute(
    _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementTagName(element),
    _config_html_js__WEBPACK_IMPORTED_MODULE_1__["default"].ATTRIBUTES.type,
    _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementAttributeType(element),
  );
}

function byInnerText(element) {
  const baseTag = _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementTagName(element);
  const value = _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementInnerText(element);
  if (value) {
    return `//${baseTag.toLowerCase()}[normalize-space(text())='${value}']`;
  }
  return null;
}

function byContainsText(element) {
  const baseTag = _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementTagName(element);
  const value = _element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementInnerText(element);
  if (value && value.length < 150) {
    return `//${baseTag.toLowerCase()}[contains(normalize-space(.),'${value}')]`;
  }
  return null;
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  byAltAttribute,
  byAriaLabel,
  byAttribute,
  byClass,
  byContainsText,
  byDataTestId,
  byId,
  byInnerText,
  byName,
  bySrcAttribute,
  byTitle,
  byTypeAttribute,
  getClassTag,
  getRoleTag,
  isFindingElement,
  isFindingMultiElements,
});


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/*!***************************************!*\
  !*** ./src/chrome/scripts/content.js ***!
  \***************************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _common_lib_dom_element_element_data_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../common/lib/dom-element/element-data.js */ "./src/common/lib/dom-element/element-data.js");
/* harmony import */ var _common_lib_dom_element_element_name_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../common/lib/dom-element/element-name.js */ "./src/common/lib/dom-element/element-name.js");
/* harmony import */ var _common_lib_dom_element_element_type_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../common/lib/dom-element/element-type.js */ "./src/common/lib/dom-element/element-type.js");
/* harmony import */ var _common_lib_dom_element_element_css_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../common/lib/dom-element/element-css.js */ "./src/common/lib/dom-element/element-css.js");
/* harmony import */ var _common_lib_dom_element_element_xpath_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../common/lib/dom-element/element-xpath.js */ "./src/common/lib/dom-element/element-xpath.js");
/* harmony import */ var _common_lib_dom_element_element_notify_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../common/lib/dom-element/element-notify.js */ "./src/common/lib/dom-element/element-notify.js");
/* harmony import */ var _common_config_web_config_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../common/config/web-config.js */ "./src/common/config/web-config.js");








const { MESSAGE_TYPE, EVENT_TYPE } = _common_config_web_config_js__WEBPACK_IMPORTED_MODULE_6__["default"];
let popupId;

chrome.runtime.onMessage.addListener((request) => {
  if ((request.from === 'popup')) {
    if (popupId && request.method !== 'updateId') {
      chrome.runtime.sendMessage({ method: MESSAGE_TYPE.extensionIsOpen, popupId });
    }
    popupId = request.popupId;
  }
});

/**
 * Chrome Listener for web page right click event
 * message from webpage to plugin
 */
window.addEventListener(EVENT_TYPE.contextMenu, (event) => {
  const element = event.target;
  const xpath = _common_lib_dom_element_element_xpath_js__WEBPACK_IMPORTED_MODULE_4__["default"].getXpathSelector(element);
  const locatorName = _common_lib_dom_element_element_name_js__WEBPACK_IMPORTED_MODULE_1__["default"].getNameAttribute(element);

  // send message to plugin from webpage
  chrome.runtime.sendMessage(
    chrome.runtime.id, // plugin unique id
    {
      method: MESSAGE_TYPE.elementRightClicked,
      popupId,
      element: {
        elementName: _common_lib_dom_element_element_name_js__WEBPACK_IMPORTED_MODULE_1__["default"].getRelativeName(element),
        elementType: _common_lib_dom_element_element_type_js__WEBPACK_IMPORTED_MODULE_2__["default"].getElementType(element),
        locatorById: _common_lib_dom_element_element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].getElementAttributeId(element),
        locatorByName: locatorName,
        isMultiLocatorName: _common_lib_dom_element_element_data_js__WEBPACK_IMPORTED_MODULE_0__["default"].isMultiLocatorName(locatorName),
        locatorByCss: _common_lib_dom_element_element_css_js__WEBPACK_IMPORTED_MODULE_3__["default"].getCssSelector(element),
        locatorByXpath: xpath,
        isMultiLocatorXpath: _common_lib_dom_element_element_xpath_js__WEBPACK_IMPORTED_MODULE_4__["default"].isMultiElementsXpath(xpath),
      },
    },
  );
});

// spy element event listener plugin to webpage
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (
    request.method === MESSAGE_TYPE.spyElement
    && sender.id === chrome.runtime.id
  ) {
    sendResponse(
      _common_lib_dom_element_element_notify_js__WEBPACK_IMPORTED_MODULE_5__["default"].notify(request.locatorType, request.locatorValue),
    );
  }

  if (
    request.method === 'tabActivated'
    && document.querySelector('.test') === null
  ) {
    // document.body.style.backgroundColor = "green";

    // const iframe = document.createElement("iframe");
    // iframe.className = "pomGeneratorFrame";
    // iframe.src = chrome.runtime.getURL("../html/panel.html");
    // document.body.appendChild(iframe);

    const injectElement = document.createElement('div');
    injectElement.id = 'pomGenerator';
    document.body.appendChild(injectElement);

    fetch(chrome.runtime.getURL('../html/panel.html'))
      .then((response) => response.text())
      .then((html) => {
        document.getElementById('pomGenerator').innerHTML = html;
        // other code
        // eg update injected elements,
        // add event listeners or logic to connect to other parts of the app
      })
      .catch((err) => {
        console.log('error= ', err);
        // handle error
      });
  }
});

})();

/******/ })()
;
//# sourceMappingURL=content.js.map